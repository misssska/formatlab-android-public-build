# FormatLab Android – public source security review (2026-10-21)

Scope: offline Android source project (Java WebView, 22 local pages, 4 active JS files, media illustrations, build scripts). This does not cover the separate FormatLab v7 backend.

## Checks completed

- Scanned source files, documentation, SVG and HTML for credentials, PEM private keys, GitHub/provider tokens, SMTP configuration, personal e-mail addresses, hardcoded hosts and machine-specific absolute paths.
- Inspected the Android manifest: **no INTERNET or broad file-storage permissions**, cleartext disabled, backups disabled, exported ContentProvider disabled.
- Checked native file export: bounded chunks, app-private cache, read-only per-URI sharing with a token, save using the Android document picker.
- Checked local WebView origin and content restrictions; the website uses a restrictive Content-Security-Policy.
- The example email addresses are placeholders (e.g. user@example.com); the hardcoded URL is the platform appassets.androidplatform.net local WebView origin. SVG namespace URLs do not fetch external resources.
- Removed the unused server SMTP email UI script, historical internal build reports and Windows-specific helper from the public-source package. Removed files are not required for the offline build.
- Automatic security gate: `python3 scripts/audit_public_source.py`.

**Result: no evidence of embedded secrets or personal data in this scoped source.** This is a source review, *not* a guarantee that all application vulnerabilities are eliminated. No Android SDK compilation, external security scan, device acceptance, or app store review has been completed.

## Publishing and supply chain

The entire APK source and any supplied zipped archive in a PUBLIC repository are public. Do **not** put passwords, signing keystores, tokens, or private project material there. The workflow uses a standard public `ubuntu-24.04` runner and read-only repository permission; it never needs credentials beyond the default checkout token.

Debug APKs are not release-signed. Generated APKs should be installed only for testing, and the build must be reviewed after the first successful run. Public source does not mean every PDF/Office/server feature runs locally; these are disabled without the remote conversion backend.

Current GitHub account had exhausted private Actions included minutes and storage (2000/2000, 0.5/0.5 GB); **public standard-hosted runner time is generally free**, but separate account billing locks can still block it. Uploading Actions artifacts also uses storage; this can separately block APK download even if compilation succeeds.
