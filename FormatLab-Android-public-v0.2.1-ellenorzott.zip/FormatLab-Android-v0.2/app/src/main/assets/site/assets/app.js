
(() => {
  'use strict';
  const EN = document.documentElement.lang === 'en';
  const t = (hu,en) => EN ? en : hu;
  const preferredSource = document.body.dataset.source || '';
  const preferredTarget = document.body.dataset.target || '';
  const $ = id => document.getElementById(id);
  const MAX_FILES=20,MAX_FILE=50*1024*1024,MAX_TOTAL=150*1024*1024,MAX_PIXELS=40_000_000;
  const imageExt=new Set(['png','jpg','jpeg','webp','gif','bmp','svg']);
  const textExt=new Set(['txt','md','markdown','html','htm']);
  const dataExt=new Set(['csv','tsv','json']);
  const formats={image:['png','jpg','webp'],text:['txt','md','html'],data:['csv','json','tsv']};
  let entries=[],working=false,nextId=0,noticeTimer,mailWidget;
  const icon=(name)=>`<svg aria-hidden="true"><use href="#i-${name}"></use></svg>`;
  const make=(tag,klass,text)=>{const el=document.createElement(tag);if(klass)el.className=klass;if(text!==undefined)el.textContent=text;return el};
  const sizeText=b=>b<1024?`${b} B`:b<1024*1024?`${(b/1024).toFixed(1)} KB`:`${(b/1024/1024).toFixed(1)} MB`;
  const extOf=name=>(name.split('.').pop()||'').toLowerCase();
  const formatName=s=>s==='jpg'?'JPG':s.toUpperCase();
  const kindOf=f=>{const ext=extOf(f.name);return imageExt.has(ext)?'image':textExt.has(ext)?'text':dataExt.has(ext)?'data':null};
  const fileStem=name=>{const idx=name.lastIndexOf('.');return idx>0?name.slice(0,idx):name};
  const safeName=s=>s.replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').slice(0,130)||'fajl';
  function showMessage(str,type='error'){$('message').textContent=str;$('message').className='message visible '+type;clearTimeout(noticeTimer);noticeTimer=setTimeout(()=>$('message').classList.remove('visible'),9500)}
  function cleanResult(e){if(e.resultUrl)URL.revokeObjectURL(e.resultUrl);e.resultUrl=null;e.blob=null;if(e.status==='ready')e.status='pending'}
  function setBusy(v){working=v;$('convertBtn').disabled=v;$('clearBtn').disabled=v;$('fileInput').disabled=v;$('convertBtn').innerHTML=v?'<span class="loading-spin"></span> Feldolgozás…':icon('switch')+t('Konvertálás','Convert');$('dropZone').style.pointerEvents=v?'none':''}
  async function addFiles(fileList){if(working)return;const files=Array.from(fileList||[]);if(!files.length)return;let errors=[];let runningSize=entries.reduce((sum,e)=>sum+e.file.size,0);
    for(const f of files){const kind=kindOf(f);if(!kind){errors.push(t(`${f.name}: nem támogatott formátum`,`${f.name}: unsupported format`));continue}if(f.size>MAX_FILE){errors.push(t(`${f.name}: 50 MB feletti fájl`,`${f.name}: exceeds 50 MB`));continue}if(entries.length>=MAX_FILES){errors.push(t(`Legfeljebb ${MAX_FILES} fájl adható hozzá`,`A maximum of ${MAX_FILES} files is allowed`));break}if(runningSize+f.size>MAX_TOTAL){errors.push(t('Az összes fájl mérete nem haladhatja meg a 150 MB-ot','Total file size cannot exceed 150 MB'));break}
      const ext=extOf(f.name);let target=kind==='image'?(ext==='png'?'webp':'png'):kind==='text'?(ext==='txt'?'html':'txt'):(ext==='json'?'csv':'json');
      if (preferredTarget && (ext===preferredSource || (preferredSource==='jpg' && ext==='jpeg')) && formats[kind].includes(preferredTarget)) target=preferredTarget;
      entries.push({id:++nextId,file:f,kind,target,status:'pending',error:'',blob:null,resultUrl:null,previewUrl:kind==='image'&&ext!=='svg'?URL.createObjectURL(f):null});runningSize+=f.size;
    }
    $('fileInput').value='';render();if(errors.length)showMessage(errors.slice(0,4).join(' · ')+(errors.length>4?' · …':''));
  }
  function render(){const list=$('fileList');list.replaceChildren();$('queue').classList.toggle('visible',entries.length>0);$('queueCount').textContent=t(`${entries.length} fájl · ${sizeText(entries.reduce((a,e)=>a+e.file.size,0))}`,`${entries.length} files · ${sizeText(entries.reduce((a,e)=>a+e.file.size,0))}`);const ready=entries.filter(e=>e.status==='ready');$('zipBtn').disabled=ready.length===0||working;$('zipBtn').textContent=ready.length>0?t(`ZIP letöltése (${ready.length})`,`Download ZIP (${ready.length})`):t('ZIP letöltése','Download ZIP');mailWidget?.refresh(ready.length>0&&!working);
    for(const e of entries){const row=make('div','file-item');let thumb;if(e.previewUrl){thumb=make('img','file-thumb');thumb.src=e.previewUrl;thumb.alt=t('Kép előnézete','Image preview');thumb.onerror=()=>{thumb.replaceWith(make('span','file-thumb',t('KÉP','IMAGE')))}}else thumb=make('span','file-thumb',e.kind==='data'?t('ADAT','DATA'):'TXT');
      const meta=make('div','file-meta'),name=make('span','file-name',e.file.name),cap=make('div','file-caption'),st=make('span','file-status '+(e.status==='ready'?'ready':e.status==='error'?'error':''));
      const states={pending:t('Konvertálásra vár','Queued'),converting:t('Feldolgozás…','Processing…'),ready:t(`Kész · ${sizeText(e.blob?.size||0)}`,`Ready · ${sizeText(e.blob?.size||0)}`),error:e.error||t('Hiba','Error')};st.textContent=states[e.status];st.title=states[e.status];cap.append(make('span','',sizeText(e.file.size)),st);meta.append(name,cap);
      const select=make('select','target-select');select.setAttribute('aria-label',t(`${e.file.name} kimeneti formátuma`,`Output format for ${e.file.name}`));for(const fmt of formats[e.kind]){const o=make('option','',formatName(fmt));o.value=fmt;o.selected=fmt===e.target;select.append(o)}select.disabled=working;select.addEventListener('change',()=>{cleanResult(e);e.target=select.value;e.error='';render()});
      row.append(thumb,meta,select);
      if(e.status==='ready'){const a=make('a','icon-btn dl');a.href=e.resultUrl;a.download=outputName(e);a.title=t('Konvertált fájl letöltése','Download converted file');a.setAttribute('aria-label',t(`Letöltés: ${outputName(e)}`,`Download: ${outputName(e)}`));a.innerHTML=icon('download');row.append(a)}
      const rm=make('button','icon-btn');rm.type='button';rm.title=t('Eltávolítás','Remove');rm.setAttribute('aria-label',t(`${e.file.name} eltávolítása`,`Remove ${e.file.name}`));rm.innerHTML=icon('trash');rm.disabled=working;rm.addEventListener('click',()=>removeEntry(e.id));row.append(rm);list.append(row)
    }
    $('queueHelp').textContent=ready.length?t(`${ready.length} kész · Külön letöltéshez kattints a nyílra, vagy válaszd a ZIP-et.`,`${ready.length} ready · Download individually or as a ZIP.`):t('Minden fájlhoz válassz célformátumot, majd indítsd a konvertálást.','Select an output format for each file, then convert.');
  }
  function removeEntry(id){const idx=entries.findIndex(e=>e.id===id);if(idx<0)return;const e=entries[idx];if(e.previewUrl)URL.revokeObjectURL(e.previewUrl);cleanResult(e);entries.splice(idx,1);render()}
  function clearAll(){if(working)return;for(const e of entries){if(e.previewUrl)URL.revokeObjectURL(e.previewUrl);cleanResult(e)}entries=[];render();$('message').classList.remove('visible')}
  function outputName(e){return safeName(fileStem(e.file.name))+'.'+e.target}
  function asBlob(s,mime){return new Blob([s],{type:mime+';charset=utf-8'})}
  function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
  function textToHtml(s){return '<!doctype html>\n<html lang="hu"><head><meta charset="utf-8"><title>Konvertált szöveg</title></head><body>\n<pre style="white-space:pre-wrap;font-family:inherit">'+escapeHTML(s)+'</pre>\n</body></html>\n'}
  function markdownInline(s){let x=escapeHTML(s);x=x.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" rel="noopener noreferrer">$1</a>');x=x.replace(/\*\*([^*\n]+)\*\*/g,'<strong>$1</strong>');x=x.replace(/\*([^*\n]+)\*/g,'<em>$1</em>');x=x.replace(/`([^`\n]+)`/g,'<code>$1</code>');return x}
  function markdownToHtml(src){const lines=src.replace(/\r\n?/g,'\n').split('\n');let out=[],list=false,code=false;for(const line of lines){if(/^\s*```/.test(line)){if(list){out.push('</ul>');list=false}out.push(code?'</code></pre>':'<pre><code>');code=!code;continue}if(code){out.push(escapeHTML(line)+'\n');continue}const head=line.match(/^(#{1,6})\s+(.+)$/),li=line.match(/^\s*[-*+]\s+(.+)$/);if(li){if(!list){out.push('<ul>');list=true}out.push('<li>'+markdownInline(li[1])+'</li>');continue}if(list){out.push('</ul>');list=false}if(head)out.push(`<h${head[1].length}>${markdownInline(head[2])}</h${head[1].length}>`);else if(/^>\s?/.test(line))out.push('<blockquote>'+markdownInline(line.replace(/^>\s?/,''))+'</blockquote>');else if(line.trim())out.push('<p>'+markdownInline(line)+'</p>')}
    if(list)out.push('</ul>');if(code)out.push('</code></pre>');return '<!doctype html>\n<html lang="hu"><head><meta charset="utf-8"><title>Konvertált Markdown</title></head><body>\n'+out.join('\n')+'\n</body></html>\n'}
  function htmlToText(raw){const doc=new DOMParser().parseFromString(raw,'text/html');doc.querySelectorAll('script,style,template,noscript,svg,iframe').forEach(x=>x.remove());doc.body.querySelectorAll('br').forEach(el=>el.replaceWith(doc.createTextNode('\n')));doc.body.querySelectorAll('p,div,h1,h2,h3,h4,h5,h6,li,blockquote,tr,section,article,pre').forEach(el=>{el.prepend(doc.createTextNode('\n'));el.append(doc.createTextNode('\n'))});return(doc.body.textContent||'').replace(/[\t ]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim()+'\n'}
  function htmlToMarkdown(raw){const doc=new DOMParser().parseFromString(raw,'text/html');doc.querySelectorAll('script,style,template,noscript,svg,iframe').forEach(x=>x.remove());function visit(node){if(node.nodeType===3)return node.nodeValue||'';if(node.nodeType!==1)return '';const tag=node.tagName.toLowerCase();if(tag==='br')return '\n';if(tag==='hr')return '\n---\n';if(tag==='img')return '';const contents=[...node.childNodes].map(visit).join('');if(/^h[1-6]$/.test(tag))return '\n'+'#'.repeat(Number(tag[1]))+' '+contents.trim()+'\n\n';if(tag==='li')return '- '+contents.trim()+'\n';if(tag==='strong'||tag==='b')return '**'+contents+'**';if(tag==='em'||tag==='i')return '*'+contents+'*';if(tag==='code')return '`'+contents+'`';if(tag==='a'){const href=node.getAttribute('href')||'';return /^https?:\/\//i.test(href)?`[${contents}](${href.replace(/[()\s]/g,'')})`:contents}if(tag==='p'||tag==='div'||tag==='section'||tag==='article'||tag==='blockquote'||tag==='pre')return '\n'+contents+'\n';if(tag==='ul'||tag==='ol')return '\n'+contents+'\n';return contents}
    return visit(doc.body).replace(/\n{3,}/g,'\n\n').trim()+'\n'}
  function mdToText(md){return md.replace(/```[\s\S]*?```/g,s=>s.slice(3,-3)).replace(/!?\[([^\]]*)\]\([^)]*\)/g,'$1').replace(/^(#{1,6}|>|[-*+])\s+/gm,'').replace(/\*\*|__|`/g,'').replace(/\*([^*\n]+)\*/g,'$1')}
  async function convertText(e){const s=await e.file.text(),from=extOf(e.file.name);let target=e.target,body;if(target==='html'){body=from==='md'||from==='markdown'?markdownToHtml(s):from==='html'||from==='htm'?s:textToHtml(s)}else if(target==='md'){body=from==='html'||from==='htm'?htmlToMarkdown(s):s}else{body=from==='html'||from==='htm'?htmlToText(s):from==='md'||from==='markdown'?mdToText(s):s}return asBlob(body,target==='html'?'text/html':target==='md'?'text/markdown':'text/plain')}
  function delimiterGuess(src,ext){if(ext==='tsv')return '\t';const line=(src.replace(/\r\n?/g,'\n').split('\n').find(x=>x.trim())||'');const count=(delim)=>{let inQuote=false,n=0;for(let i=0;i<line.length;i++){if(line[i]==='"'){if(inQuote&&line[i+1]==='"')i++;else inQuote=!inQuote}else if(!inQuote&&line[i]===delim)n++}return n};return count(';')>count(',')?';':','}
  function parseDelimited(src,delim){src=src.replace(/^\uFEFF/,'');let rows=[],row=[],cell='',quoted=false;for(let i=0;i<src.length;i++){const c=src[i];if(c==='"'){if(quoted&&src[i+1]==='"'){cell+='"';i++}else if(!quoted&&cell===''){quoted=true}else if(quoted){quoted=false}else{cell+='"'}}else if(!quoted&&c===delim){row.push(cell);cell=''}else if(!quoted&&(c==='\r'||c==='\n')){if(c==='\r'&&src[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v!==''))rows.push(row);row=[];cell=''}else cell+=c}
    if(quoted)throw Error(t('Hibás CSV/TSV: lezáratlan idézőjel','Malformed CSV/TSV: unclosed quote'));row.push(cell);if(row.some(v=>v!==''))rows.push(row);return rows}
  function toDelimited(rows,delimiter){const q=v=>{let s=v===null||v===undefined?'':typeof v==='object'?JSON.stringify(v):String(v);return /["\r\n]/.test(s)||s.includes(delimiter)?'"'+s.replace(/"/g,'""')+'"':s};return rows.map(r=>r.map(q).join(delimiter)).join('\r\n')+'\r\n'}
  async function convertData(e){const src=await e.file.text(),from=extOf(e.file.name),target=e.target;let rows,objects;if(from==='json'){let value;try{value=JSON.parse(src.replace(/^\uFEFF/,''))}catch{throw Error(t('A JSON fájl szintaktikája hibás','Invalid JSON syntax'))}if(!Array.isArray(value))value=[value];if(!value.length)throw Error(t('Üres JSON-tömböt nem lehet táblázattá alakítani','Cannot convert an empty JSON array to a table'));if(value.some(v=>v===null||typeof v!=='object'||Array.isArray(v)))throw Error(t('A JSON gyökere objektumok tömbje legyen','JSON must be an object or array of objects'));objects=value;const fields=[...new Set(objects.flatMap(o=>Object.keys(o)))];if(!fields.length)throw Error(t('A JSON objektumoknak nincs oszlopuk','JSON objects have no columns'));rows=[fields,...objects.map(o=>fields.map(k=>o[k]??''))]}else{rows=parseDelimited(src,delimiterGuess(src,from));if(!rows.length)throw Error(t('Az adatfájl üres','The data file is empty'));const headers=rows[0];if(new Set(headers).size!==headers.length)throw Error(t('Az oszlopnevek nem lehetnek azonosak','Column names must be unique'));objects=rows.slice(1).map(row=>Object.fromEntries(headers.map((k,i)=>[k,row[i]??''])))}
    if(target==='json')return asBlob(JSON.stringify(objects,null,2)+'\n','application/json');return asBlob(toDelimited(rows,target==='tsv'?'\t':','),target==='csv'?'text/csv':'text/tab-separated-values')}
  function validateSvg(xml){
    if (xml.length > 5_000_000 || /<!DOCTYPE|<!ENTITY|<\?xml-stylesheet/i.test(xml)) throw Error(t('A megadott SVG nem biztonságos vagy túl összetett','SVG is unsafe or too complex'));
    const doc=new DOMParser().parseFromString(xml,'image/svg+xml');
    const root=doc.documentElement;
    if(!root || root.localName!=='svg' || doc.querySelector('parsererror')) throw Error(t('Érvénytelen SVG-fájl','Invalid SVG file'));
    const tags=new Set(['svg','g','rect','circle','ellipse','line','polyline','polygon','path','defs','linearGradient','radialGradient','stop','title','desc']);
    const attrs=new Set(['xmlns','width','height','viewBox','fill','fill-rule','stroke','stroke-width','stroke-linecap','stroke-linejoin','stroke-dasharray','stroke-dashoffset','opacity','fill-opacity','stroke-opacity','transform','d','x','y','x1','y1','x2','y2','cx','cy','r','rx','ry','points','offset','stop-color','stop-opacity','gradientUnits','gradientTransform','fx','fy','fr','spreadMethod','preserveAspectRatio','version']);
    for(const el of doc.querySelectorAll('*')){
      if(!tags.has(el.localName)) throw Error(t('Az SVG nem támogatott vagy aktív elemeket tartalmaz','SVG contains unsupported or active elements'));
      for(const a of el.attributes){
        if(!attrs.has(a.name) || (a.name==='xmlns' ? a.value!=='http://www.w3.org/2000/svg' : /url\s*\(|@import|(?:javascript|data|https?|file)\s*:/i.test(a.value))) throw Error(t('Az SVG tiltott hivatkozást vagy attribútumot tartalmaz','SVG contains a forbidden reference or attribute'));
      }
    }
  }
  async function convertImage(e){
    const from=extOf(e.file.name);
    if(from==='svg')validateSvg(await e.file.text());
    const url=URL.createObjectURL(e.file);
    let im;
    try{im=await new Promise((resolve,reject)=>{const img=new Image();const timer=setTimeout(()=>reject(Error(t('A kép betöltése túllépte az időkorlátot','Image loading timed out'))),18000);img.onload=()=>{clearTimeout(timer);resolve(img)};img.onerror=()=>{clearTimeout(timer);reject(Error(t('A kép nem nyitható meg','Image cannot be opened')))};img.src=url})}
    finally{URL.revokeObjectURL(url)}
    let w=im.naturalWidth,h=im.naturalHeight;
    if(!w||!h)throw Error(t('Nem olvashatók a képméretek','Missing image dimensions'));
    const width=Number($('maxWidth').value)||Infinity,height=Number($('maxHeight').value)||Infinity;
    const factor=Math.min(1,width/w,height/h);w=Math.max(1,Math.round(w*factor));h=Math.max(1,Math.round(h*factor));
    if(w>8000||h>8000||w*h>MAX_PIXELS)throw Error(t('Túl nagy kép. Adj meg kisebb méreteket.','Image too large. Specify smaller dimensions.'));
    const targetField=$('targetImageMb'),requested=targetField?.value.trim()||'';
    const limit=requested?Number(requested)*1048576:0;
    if(requested&&(!Number.isFinite(limit)||limit<.05*1048576||limit>40*1048576))throw Error(t('A célméret 0,05–40 MB lehet.','Target must be 0.05–40 MB.'));
    const mime={png:'image/png',jpg:'image/jpeg',webp:'image/webp'}[e.target];
    const canvas=document.createElement('canvas');
    const encode=(quality)=>new Promise((ok,fail)=>canvas.toBlob(b=>b?ok(b):fail(Error(t('Képkódolási hiba','Image encoding error'))),mime,quality));
    let best=null;
    try{
      for(const scale of (limit?[1,.85,.72,.60,.48,.38,.30,.22]:[1])){
        const sw=Math.max(1,Math.round(w*scale)),sh=Math.max(1,Math.round(h*scale));
        canvas.width=sw;canvas.height=sh;
        const ctx=canvas.getContext('2d',{alpha:e.target!=='jpg'});
        if(!ctx)throw Error('Canvas not supported');
        if(e.target==='jpg'){ctx.fillStyle=$('background').value;ctx.fillRect(0,0,sw,sh)}
        ctx.imageSmoothingEnabled=true;ctx.imageSmoothingQuality='high';ctx.drawImage(im,0,0,sw,sh);
        const qs=limit&&e.target!=='png'?[Number($('quality').value)/100,.65,.48,.32,.20]:[Number($('quality').value)/100];
        for(const q of qs){const out=await encode(q);
          if(out.type!==mime)throw Error(t('A böngésződ nem támogatja a kimeneti formátumot.','Unsupported output image format.'));
          if(!best||out.size<best.size)best=out;
          if(limit&&out.size<=limit)return out;
          if(!limit)return out;
        }
      }
      if(limit)throw Error(t('A megadott célméret nem érhető el a biztonságos méretkorlátok mellett. A legkisebb eredmény: ','Target size cannot be reached within safe limits. Smallest result: ')+sizeText(best?.size||0));
      return best;
    }finally{canvas.width=0;canvas.height=0}
  }
  async function convertAll(){if(working||!entries.length)return;setBusy(true);let ok=0,fail=0;try{for(const e of entries){if(e.status==='ready')continue;cleanResult(e);e.status='converting';render();await new Promise(r=>setTimeout(r,0));try{const blob=e.kind==='image'?await convertImage(e):e.kind==='text'?await convertText(e):await convertData(e);e.blob=blob;e.resultUrl=URL.createObjectURL(blob);e.status='ready';ok++}catch(ex){e.status='error';e.error=ex instanceof Error?ex.message:t('Ismeretlen hiba','Unknown error');fail++}render()}}finally{setBusy(false);render()}showMessage(t(`${ok} fájl sikeresen konvertálva${fail?`, ${fail} hiba. A hibák részletei a fájllistában láthatók.`:'. A letöltéshez kattints a nyílra vagy a ZIP gombra.'}`,`${ok} file(s) converted${fail?`, ${fail} error(s). See details in the file list.`:'. Download individually or as a ZIP.'}`),fail?'error':'success')}
  const CRC_TABLE=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=c&1?0xEDB88320^(c>>>1):c>>>1;t[n]=c>>>0}return t})();
  function crc32(bytes){let c=0xFFFFFFFF;for(const b of bytes)c=CRC_TABLE[(c^b)&255]^(c>>>8);return(c^0xFFFFFFFF)>>>0}
  function u16(view,pos,n){view.setUint16(pos,n,true)}function u32(view,pos,n){view.setUint32(pos,n>>>0,true)}
  async function makeZip(ready){const encoder=new TextEncoder(),parts=[],central=[];let offset=0;const dt=new Date(),time=((dt.getHours()&31)<<11)|((dt.getMinutes()&63)<<5)|((Math.floor(dt.getSeconds()/2))&31),date=(((Math.max(1980,dt.getFullYear())-1980)&127)<<9)|(((dt.getMonth()+1)&15)<<5)|(dt.getDate()&31);const used=new Set();
    for(const e of ready){let name=outputName(e),seq=2;while(used.has(name)){name=`${safeName(fileStem(e.file.name))}_${seq++}.${e.target}`}used.add(name);const nameBytes=encoder.encode(name),data=new Uint8Array(await e.blob.arrayBuffer()),crc=crc32(data);const local=new Uint8Array(30+nameBytes.length),lv=new DataView(local.buffer);u32(lv,0,0x04034b50);u16(lv,4,20);u16(lv,6,0x0800);u16(lv,8,0);u16(lv,10,time);u16(lv,12,date);u32(lv,14,crc);u32(lv,18,data.length);u32(lv,22,data.length);u16(lv,26,nameBytes.length);u16(lv,28,0);local.set(nameBytes,30);parts.push(local,data);
      const cd=new Uint8Array(46+nameBytes.length),cv=new DataView(cd.buffer);u32(cv,0,0x02014b50);u16(cv,4,20);u16(cv,6,20);u16(cv,8,0x0800);u16(cv,10,0);u16(cv,12,time);u16(cv,14,date);u32(cv,16,crc);u32(cv,20,data.length);u32(cv,24,data.length);u16(cv,28,nameBytes.length);u16(cv,30,0);u16(cv,32,0);u16(cv,34,0);u16(cv,36,0);u32(cv,38,0);u32(cv,42,offset);cd.set(nameBytes,46);central.push(cd);offset+=local.length+data.length}
    const cdSize=central.reduce((n,c)=>n+c.length,0),end=new Uint8Array(22),ev=new DataView(end.buffer);u32(ev,0,0x06054b50);u16(ev,4,0);u16(ev,6,0);u16(ev,8,central.length);u16(ev,10,central.length);u32(ev,12,cdSize);u32(ev,16,offset);u16(ev,20,0);return new Blob([...parts,...central,end],{type:'application/zip'})}
  async function downloadZip(){const ready=entries.filter(e=>e.status==='ready');if(!ready.length||working)return;$('zipBtn').disabled=true;try{const zip=await makeZip(ready);const u=URL.createObjectURL(zip),a=document.createElement('a');a.href=u;a.download='formatlab-konvertalt-fajlok.zip';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000)}catch(err){showMessage(t('A ZIP fájl létrehozása sikertelen: ','Could not create ZIP file: ')+(err?.message||t('ismeretlen hiba','unknown error')))}finally{$('zipBtn').disabled=false}}
  if(window.FormatLabEmail){mailWidget=window.FormatLabEmail.mount({container:$('queue').querySelector('.queue-actions'),zip:true,getAttachment:async()=>({blob:await makeZip(entries.filter(e=>e.status==='ready')),filename:'formatlab-converted-files.zip'})});}
  if(window.FormatLabShare)window.FormatLabShare.init('flShare',async()=>{const ready=entries.filter(e=>e.status==='ready');if(!ready.length)return null;if(ready.length===1)return {blob:ready[0].blob,name:outputName(ready[0])};return {blob:await makeZip(ready),name:'formatlab-konvertalt-fajlok.zip'};});
  $('browseBtn').addEventListener('click',e=>{e.stopPropagation();$('fileInput').click()});$('dropZone').addEventListener('click',e=>{if(e.target.closest('button'))return;$('fileInput').click()});$('dropZone').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();$('fileInput').click()}});$('fileInput').addEventListener('change',e=>addFiles(e.target.files));
  for(const evt of ['dragenter','dragover'])$('dropZone').addEventListener(evt,e=>{e.preventDefault();e.stopPropagation();if(!working)$('dropZone').classList.add('dragover')});for(const evt of ['dragleave','drop'])$('dropZone').addEventListener(evt,e=>{e.preventDefault();e.stopPropagation();$('dropZone').classList.remove('dragover')});$('dropZone').addEventListener('drop',e=>addFiles(e.dataTransfer.files));
  if($('targetImageMb'))$('targetImageMb').addEventListener('input',()=>{entries.filter(e=>e.kind==='image').forEach(cleanResult);render()});$('quality').addEventListener('input',()=>{$('qualityValue').textContent=$('quality').value+'%';entries.filter(e=>e.kind==='image').forEach(cleanResult);render()});$('background').addEventListener('input',()=>{$('backgroundValue').textContent=$('background').value.toUpperCase();entries.filter(e=>e.kind==='image').forEach(cleanResult);render()});for(const id of ['maxWidth','maxHeight'])$(id).addEventListener('input',()=>{entries.filter(e=>e.kind==='image').forEach(cleanResult);render()});$('clearBtn').addEventListener('click',clearAll);$('convertBtn').addEventListener('click',convertAll);$('zipBtn').addEventListener('click',downloadZip);
})();
