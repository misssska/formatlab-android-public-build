/* User-controlled native sharing, RFC822 draft and optional consent-based SMTP. */
(() => {
  'use strict';
  const EN=document.documentElement.lang==='en';
  const t=(hu,en)=>EN?en:hu;
  const isEmail=s=>/^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,24}$/i.test(s)&&s.length<=254;
  const size=b=>(b/1048576).toFixed(2)+' MB';
  const make=(tag,name,text)=>{const e=document.createElement(tag);if(name)e.className=name;if(text!=null)e.textContent=text;return e};
  const base64=blob=>new Promise((ok,fail)=>{const r=new FileReader();r.onerror=()=>fail(Error('Cannot encode file'));r.onload=()=>ok(String(r.result).split(',')[1]||'');r.readAsDataURL(blob)});
  const download=(blob,name)=>{const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)};
  function init(id,getFile){
    const root=document.getElementById(id);if(!root)return;
    const heading=make('h3','share-title',t('Küldés e-mailben','Send by email'));
    const note=make('p','share-note',t('A kész fájlt megoszthatod az eszközöd e-mail-alkalmazásával, vagy küldhetsz egy csatolt .eml levéltervezetet.','Share a completed file through your device email app, or download an email draft (.eml) with attachment.'));
    const form=make('div','share-form');
    const label=(text,input)=>{const wrap=make('label','share-field');wrap.append(make('span','',text),input);return wrap};
    const to=make('input','share-input');to.type='email';to.placeholder='cimzett@example.com';to.autocomplete='email';to.maxLength=254;
    const message=make('textarea','share-input');message.rows=3;message.maxLength=2000;message.placeholder=t('Írj kísérőszöveget…','Write a message…');
    form.append(label(t('Címzett','Recipient'),to),label(t('Kísérőszöveg','Message'),message));
    const actions=make('div','share-actions');
    const native=make('button','share-button',t('Megosztás alkalmazással','Share with an app'));
    const eml=make('button','share-button secondary',t('E-mail-tervezet (.eml)','Email draft (.eml)'));
    for(const b of [native,eml])b.type='button';
    actions.append(native,eml);
    const state=make('p','share-status');state.setAttribute('role','status');state.setAttribute('aria-live','polite');
    root.append(heading,note,form,actions,state);
    async function file(){const result=await getFile();if(!result||!result.blob||!result.name)throw Error(t('Előbb konvertálj egy fájlt.','Convert a file first.'));return result}
    const validate=()=>{if(to.value.trim()&&!isEmail(to.value.trim()))throw Error(t('Hibás e-mail-cím','Invalid email address'));if(message.value.length>2000)throw Error('Message too long')};
    async function perform(action){
      state.textContent='';
      try{
        validate();const result=await file();
        if(action==='native'){
          if(window.FormatLabAndroid?.shareBlob){
            await window.FormatLabAndroid.shareBlob(result.blob,result.name,to.value.trim(),message.value);
            state.textContent=t('Válaszd ki a levelezőalkalmazást, ellenőrizd a címzettet, majd küldd el.','Select an email app, check the recipient and send.');
            return;
          }
          const attachment=new File([result.blob],result.name,{type:result.blob.type||'application/octet-stream'});
          if(!navigator.share||!navigator.canShare?.({files:[attachment]}))throw Error(t('Ezen a böngészőn nem támogatott a fájlmegosztás. Használd az .eml tervezetet.','File sharing is not supported here. Use the .eml draft.'));
          const preface=to.value.trim()?t('Címzett: ','Recipient: ')+to.value.trim()+'\n\n':'';
          await navigator.share({files:[attachment],title:'FormatLab: '+result.name,text:preface+message.value});
          state.textContent=t('A megosztási ablak megnyílt. Az e-mail tényleges elküldését az alkalmazásodban végezd el.','Share sheet opened. Complete sending inside the selected app.');
        }else if(action==='draft'){
          if(result.blob.size>7*1048576)throw Error(t('Az .eml levélmelléklet maximum 7 MB lehet. Csökkentsd a fájlt.','Email draft attachments are limited to 7 MB. Compress the file.'));
          const boundary='formatlab-'+(crypto.randomUUID?crypto.randomUUID():Date.now());
          const safeName=result.name.replace(/["\r\n\\]/g,'_').replace(/[^\x20-\x7e]/g,'_');
          const recipient=to.value.trim();
          const lines=['MIME-Version: 1.0','To: '+recipient,'Subject: FormatLab converted file','Content-Type: multipart/mixed; boundary="'+boundary+'"','','--'+boundary,'Content-Type: text/plain; charset="utf-8"','Content-Transfer-Encoding: base64','',''];
          const enc=new TextEncoder().encode(message.value||t('Küldöm a konvertált fájlt.','Here is the converted file.'));
          let str='';for(const x of enc)str+=String.fromCharCode(x);const bodyB64=btoa(str);lines.push(...bodyB64.match(/.{1,76}/g)||[]);
          lines.push('','--'+boundary,'Content-Type: application/octet-stream; name="'+safeName+'"','Content-Disposition: attachment; filename="'+safeName+'"','Content-Transfer-Encoding: base64','');
          const encoded=await base64(result.blob);lines.push(...encoded.match(/.{1,76}/g)||[],'','--'+boundary+'--','');
          download(new Blob([lines.join('\r\n')],{type:'message/rfc822'}),'formatlab-leveltervezet.eml');
          state.textContent=t('Az .eml fájl elkészült. Nyisd meg egy levelezőben, ellenőrizd, majd küldd el.','Email draft downloaded. Open in a mail app, review, then send.');
        }

      }catch(err){if(err?.name==='AbortError')return;state.textContent=t('Nem sikerült: ','Could not complete: ')+String(err?.message||err)}
    }
    native.addEventListener('click',()=>perform('native'));
    eml.addEventListener('click',()=>perform('draft'));
  }
  window.FormatLabShare={init};
})();
