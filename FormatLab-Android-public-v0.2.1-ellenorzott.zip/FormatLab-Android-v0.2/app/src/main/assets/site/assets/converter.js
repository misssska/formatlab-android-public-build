(() => {
  'use strict';
  const EN=document.documentElement.lang==='en';
  const t=(hu,en)=>EN?en:hu;
  const $=id=>document.getElementById(id);
  let pairs={},formats=[],file=null,controller=null,ready=null,mailWidget=null,serverAvailable=false;
  let vectorPreviewUrls=[];
  let vectorPhysicalTouched=false;
  let maxDoc=25*1024*1024,maxMedia=40*1024*1024,maxCompressImage=60*1024*1024;
  const mediaExt=new Set(['mp3','wav','flac','ogg','m4a','aac','mp4','webm','mov','mkv','avi']);
  const imageExt=new Set(['png','jpg','jpeg','webp','bmp','gif','tiff','avif']);
  const ext=s=>(s.split('.').pop()||'').toLowerCase();
  const human=b=>b<1048576?(b/1024).toFixed(0)+' KB':(b/1048576).toFixed(2)+' MB';
  const status=(s,kind='')=>{const node=$('c3Status');node.textContent=s;node.className='c3-alert show '+kind};
  function mode(){return $('c3Mode').value}
  function allow(){if(!file||!serverAvailable)return false;const src=ext(file.name);return mode()==='convert'?!!$('c3Target').value:(formats.includes(src)&&!!Number($('c3Size').value))}
  function sizeLimit(source){return mode()==='compress'&&imageExt.has(source)?maxCompressImage:mediaExt.has(source)?maxMedia:maxDoc}
  function vectorSelected(){return mode()==='convert'&&$('c3Target').value==='svg'&&!!file}
  function clearVectorPreview(){
    for(const url of vectorPreviewUrls)URL.revokeObjectURL(url);
    vectorPreviewUrls=[];
    $('c3VectorPreview').hidden=true;
    $('c3VectorOriginal').removeAttribute('src');
    $('c3VectorResult').removeAttribute('src');
  }
  function physicalValid(){
    if(!vectorSelected()||!$('c3UsePhysical').checked)return true;
    return ['c3Width','c3Height'].every(id=>{const n=Number($(id).value);return $(id).value.trim()!==''&&Number.isFinite(n)&&n>=10&&n<=3000});
  }
  function validFile(){return file&&file.size>0&&file.size<=sizeLimit(ext(file.name))&&allow()&&physicalValid()}
  function showVectorControls(){
    const visible=vectorSelected();
    $('c3Vector').classList.toggle('show',visible);
    const dims=$('c3VectorDimensions');dims.hidden=!visible||!$('c3UsePhysical').checked;
    // Default large-format Hawaii plotter preset is opt-in, never force a page size on generic art.
    readyButton();
  }
  function showControls(){
    const shrinking=mode()==='compress';
    $('c3SizeField').classList.toggle('show',shrinking);
    $('c3Target').style.display=shrinking?'none':'';
    document.querySelector('label[for="c3Target"]').style.display=shrinking?'none':'';
    if(shrinking){$('c3Submit').textContent=t('Méret csökkentése és letöltés','Compress & download')}
    else {$('c3Submit').textContent=t('Konvertálás és letöltés','Convert & download')}
    ready=null;mailWidget?.refresh(false);clearVectorPreview();
    if(file)choose(file);else showVectorControls();
  }
  function readyButton(){$('c3Submit').disabled=!validFile()||!!controller}
  function choose(f){
    file=f||null;ready=null;mailWidget?.refresh(false);clearVectorPreview();
    $('c3File').classList.toggle('show',!!file);
    $('c3Filename').textContent=file?.name||'';
    $('c3Filesize').textContent=file?human(file.size):'';
    const select=$('c3Target');select.replaceChildren();
    if(!file){showVectorControls();return}
    const source=ext(file.name),targets=pairs[source]||[];
    if(mode()==='convert'){
      for(const value of targets){const option=document.createElement('option');option.value=value;option.textContent=value.toUpperCase()+(source==='pdf'&&['png','jpg'].includes(value)?t(' (ZIP, oldalanként)',' (ZIP, per page)'):'');select.append(option)}
      select.value=targets.includes('svg')?'svg':targets.includes('pdf')?'pdf':targets.includes('docx')?'docx':targets[0]||'';
    }
    if(!serverAvailable)status(t('Az izolált konvertáló jelenleg nem elérhető.','The isolated converter is currently offline.'),'error');
    else if(!allow())status(t('Ez a fájl ebben a módban nem támogatott.','This file is not supported in this mode.'),'error');
    else if(file.size>sizeLimit(source))status(t('A fájl túl nagy. Korlát: ','File too large. Limit: ')+human(sizeLimit(source)),'error');
    else status(t('A fájl csak a gomb megnyomásakor töltődik fel.','The file uploads only after you press the button.'));
    showVectorControls();
  }
  async function loadFormats(){
    // The native Android APK is strictly offline: do not even attempt an /api request.
    if(window.FormatLabNative){
      serverAvailable=false;
      $('c3Server').textContent=t('Offline – szerver szükséges','Offline – server required');
      status(t('A PDF, DOC/DOCX, videó és SVG-vektorizálás nem érhető el ebben az offline alkalmazásban.',
        'PDF, DOC/DOCX, video and SVG vectorization are unavailable in this offline app.'),'error');
      $('c3Submit').disabled=true;
      $('c3Input').disabled=true;
      return;
    }
    try{
      const r=await fetch('/api/formats',{cache:'no-store'});
      if(!r.ok)throw Error('offline');
      const data=await r.json();pairs=data.pairs;formats=data.compression_formats||[];
      maxDoc=data.max_bytes;maxMedia=data.max_media_bytes;maxCompressImage=data.max_compress_image_bytes;
      serverAvailable=data.server_upload!==false;
      $('c3Server').textContent=serverAvailable?t('Konvertáló elérhető','Converter online'):t('Feldolgozó nem elérhető','Converter worker offline');
      status(serverAvailable?t('PDF/Office/média konverter és tömörítő elérhető.','PDF/Office/media converter and compression are available.'):t('Az izolált feldolgozó jelenleg nem elérhető.','The isolated converter worker is currently offline.'),serverAvailable?'':'error');
      if(file)choose(file);
    }catch{
      serverAvailable=false;
      $('c3Server').textContent=t('Szerver nem elérhető','Server offline');
      status(t('A bővített funkciókhoz a FormatLab API-szerver szükséges.','Extended features require the FormatLab API server.'),'error');
    }
  }
  function busy(value){
    $('c3Input').disabled=value;
    $('c3Mode').disabled=value;
    $('c3Size').disabled=value;
    if(value)$('c3Submit').textContent=t('Feldolgozás…','Processing…');
    else $('c3Submit').textContent=mode()==='compress'?t('Méret csökkentése és letöltés','Compress & download'):t('Konvertálás és letöltés','Convert & download');
    readyButton();
  }
  async function process(){
    if(!validFile()||controller)return;
    const source=ext(file.name);
    const shrink=mode()==='compress';
    const targetMB=Number($('c3Size').value);
    if(shrink&&(targetMB<.05||targetMB>40||!Number.isFinite(targetMB))){status(t('A célméret 0,05–40 MB között lehet.','Target size must be 0.05–40 MB.'),'error');return}
    const selectedTarget=$('c3Target').value;
    if(!physicalValid()){status(t('A fizikai méret 10–3000 mm között lehet.','Physical size must be 10–3000 mm.'),'error');return}
    ready=null;mailWidget?.refresh(false);clearVectorPreview();controller=new AbortController();busy(true);
    status(t('Fájl feltöltése és feldolgozása…','Uploading and processing…'));
    try{
      const body=new FormData();body.append('file',file,file.name);
      if(shrink)body.append('target_mb',String(targetMB));
      else {
        body.append('target',selectedTarget);
        if(selectedTarget==='svg'){
          body.append('vector_preset',$('c3VectorPreset').value);
          if($('c3UsePhysical').checked){
            body.append('width_mm',$('c3Width').value);
            body.append('height_mm',$('c3Height').value);
          }
        }
      }
      const response=await fetch(shrink?'/api/compress':'/api/convert',{method:'POST',body,signal:controller.signal,cache:'no-store'});
      if(!response.ok){let message=response.status+' '+response.statusText;try{message=(await response.json()).detail||message}catch{}throw Error(message)}
      const blob=await response.blob();
      const disposition=response.headers.get('Content-Disposition')||'';
      const downloaded=/filename="([^"]+)"/.exec(disposition)?.[1]||'result.bin';
      const suffix=ext(downloaded);
      const stem=file.name.replace(/\.[^.]+$/,'').replace(/[^a-z0-9_\-]/gi,'_').slice(0,55)||'file';
      const filename=stem+(shrink?'-compressed':'-converted')+'.'+suffix;
      ready={blob,name:filename};mailWidget?.refresh(true);
      if(suffix==='svg'){
        const original=URL.createObjectURL(file),result=URL.createObjectURL(blob);
        vectorPreviewUrls.push(original,result);
        $('c3VectorOriginal').src=original;
        $('c3VectorResult').src=result;
        $('c3VectorPreview').hidden=false;
      }
      const u=URL.createObjectURL(blob),a=document.createElement('a');a.href=u;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),30000);
      const achieved=shrink?response.headers.get('X-Target-Met')==='1':true;
      status(t('Kész: ','Done: ')+filename+' ('+human(blob.size)+')'+(shrink&&!achieved?t(' — a kívánt célméret nem érhető el, az eredmény még mindig nagyobb.',' — target size not reached, output is still larger.'):'')+' '+t('Lent e-mailben is megosztható.','You can share it by email below.'),achieved?'success':'');
    }catch(error){status((error.name==='AbortError'?t('Megszakítva','Cancelled'):t('Hiba: ','Error: ')+String(error.message)),'error')}
    finally{controller=null;busy(false)}
  }
  $('c3Input').addEventListener('change',e=>choose(e.target.files?.[0]));
  $('c3Mode').addEventListener('change',showControls);
  $('c3Target').addEventListener('change',()=>{ready=null;mailWidget?.refresh(false);clearVectorPreview();showVectorControls()});
  $('c3VectorPreset').addEventListener('change',()=>{
    if($('c3VectorPreset').value.startsWith('plotter_')&&!vectorPhysicalTouched){
      $('c3UsePhysical').checked=true;
    }
    ready=null;mailWidget?.refresh(false);clearVectorPreview();showVectorControls();
  });
  $('c3UsePhysical').addEventListener('change',()=>{vectorPhysicalTouched=true;ready=null;mailWidget?.refresh(false);clearVectorPreview();showVectorControls()});
  for(const id of ['c3Width','c3Height'])$(id).addEventListener('input',()=>{ready=null;mailWidget?.refresh(false);clearVectorPreview();readyButton()});
  $('c3Size').addEventListener('input',()=>{ready=null;mailWidget?.refresh(false);readyButton()});
  $('c3Drop').addEventListener('click',()=>!controller&&$('c3Input').click());
  $('c3Drop').addEventListener('keydown',e=>{if((e.key==='Enter'||e.key===' ')&&!controller){e.preventDefault();$('c3Input').click()}});
  for(const evt of ['dragenter','dragover'])$('c3Drop').addEventListener(evt,e=>{e.preventDefault();$('c3Drop').classList.add('drag')});
  for(const evt of ['dragleave','drop'])$('c3Drop').addEventListener(evt,e=>{e.preventDefault();$('c3Drop').classList.remove('drag')});
  $('c3Drop').addEventListener('drop',e=>{if(!controller)choose(e.dataTransfer.files?.[0])});
  $('c3Submit').addEventListener('click',process);
  if(window.FormatLabShare)window.FormatLabShare.init('flShare',async()=>ready);
  if(window.FormatLabEmail){mailWidget=window.FormatLabEmail.mount({container:$('flShare'),zip:false,getAttachment:async()=>ready?{blob:ready.blob,filename:ready.name}:null});mailWidget.refresh(false);}
  showControls();loadFormats();
})();
