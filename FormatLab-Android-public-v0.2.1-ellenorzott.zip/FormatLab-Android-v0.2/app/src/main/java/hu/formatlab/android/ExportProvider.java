package hu.formatlab.android;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

/** Grants read-only, per-URI access to app-private exported files via Android Sharesheet. */
public final class ExportProvider extends ContentProvider {
    private static final String AUTHORITY = "hu.formatlab.android.exports";

    static Uri uriFor(String token, String name) {
        return new Uri.Builder().scheme("content").authority(AUTHORITY)
            .appendPath("file").appendPath(token).appendPath(name).build();
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (!AUTHORITY.equals(uri.getAuthority()) || uri.getPathSegments().size() != 3
            || !"file".equals(uri.getPathSegments().get(0))) throw new FileNotFoundException();
        String token = uri.getPathSegments().get(1);
        if (!token.matches("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"))
            throw new FileNotFoundException();
        File f = new File(new File(getContext().getCacheDir(), "exports"), token + ".bin");
        if (!f.isFile()) throw new FileNotFoundException();
        return f;
    }

    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri uri) {
        try { resolve(uri); return MainActivity.mimeOf(uri.getLastPathSegment()); }
        catch (FileNotFoundException e) { return null; }
    }
    @Override public Cursor query(Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        try {
            File f = resolve(uri);
            if (projection == null) projection = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
            MatrixCursor c = new MatrixCursor(projection);
            Object[] values = new Object[projection.length];
            for (int i=0; i<projection.length; i++) {
                if (OpenableColumns.DISPLAY_NAME.equals(projection[i])) values[i] = uri.getLastPathSegment();
                if (OpenableColumns.SIZE.equals(projection[i])) values[i] = f.length();
            }
            c.addRow(values);
            return c;
        } catch (FileNotFoundException e) { return null; }
    }
    @Override public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new FileNotFoundException("Read only");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }
    @Override public Uri insert(Uri uri, ContentValues values) { throw new UnsupportedOperationException(); }
    @Override public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) { return 0; }
    @Override public int delete(Uri uri, String selection, String[] selectionArgs) { return 0; }
}
