package hu.formatlab.android;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Locale;
import java.util.UUID;

public final class MainActivity extends Activity {
    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/index.html";
    private static final int PICK_FILES = 101;
    private static final int SAVE_FILE = 102;
    private static final long MAX_EXPORT_BYTES = 150L * 1024 * 1024;
    private static final int MAX_CHUNK_BYTES = 96 * 1024;
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private ExportSession writing;
    private volatile ExportSession pendingSave;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private static final class ExportSession {
        String token;
        String fileName;
        String mime;
        String mode;
        String recipient;
        String message;
        long size;
        long written;
        File file;
        FileOutputStream stream;
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xff0b1625);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Android SAF picker content:// URI; not file:// URLs.
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.setWebContentsDebuggingEnabled(false);
        webView.addJavascriptInterface(new NativeExports(), "FormatLabNative");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (isLocal(uri)) return false;
                if (request.isForMainFrame()) {
                    String scheme = uri.getScheme();
                    if ("https".equalsIgnoreCase(scheme) || "mailto".equalsIgnoreCase(scheme)) {
                        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                        catch (Exception e) { toast("Nincs telepített megnyitó alkalmazás."); }
                    }
                }
                return true;
            }
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return localResponse(request.getUrl());
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try { startActivityForResult(intent, PICK_FILES); }
                catch (Exception ex) { fileCallback.onReceiveValue(null); fileCallback = null; toast("Nem nyitható meg a fájlválasztó."); }
                return true;
            }
        });
        clearOldExports();
        webView.loadUrl(HOME);
    }

    private static boolean isLocal(Uri uri) {
        return "https".equalsIgnoreCase(uri.getScheme()) && HOST.equalsIgnoreCase(uri.getHost())
            && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    private WebResourceResponse localResponse(Uri url) {
        if (!isLocal(url)) return failure(403, "Forbidden");
        String p = url.getPath();
        if (p == null || p.equals("/") || p.isEmpty()) p = "/index.html";
        if (p.startsWith("/api/")) return json(503, "{\"detail\":\"Offline Android: a szerveres PDF/Office/SVG feldolgozás nem érhető el.\"}");
        if (p.endsWith("/")) p += "index.html";
        if (p.indexOf('\\') >= 0 || p.indexOf('\0') >= 0) return failure(403, "Forbidden");
        for (String part : p.split("/")) if (part.equals("..") || part.equals(".")) return failure(403, "Forbidden");
        if (!p.startsWith("/")) return failure(403, "Forbidden");
        try {
            InputStream stream = getAssets().open("site" + p);
            String mime = mimeOf(p);
            return new WebResourceResponse(mime, mime.startsWith("text/") || mime.contains("javascript") || mime.contains("json") ? "UTF-8" : null,
                200, "OK", Collections.singletonMap("Cache-Control", "no-store"), stream);
        } catch (Exception e) { return failure(404, "Not Found"); }
    }

    private static WebResourceResponse json(int code, String data) {
        return new WebResourceResponse("application/json", "UTF-8", code, "Unavailable",
            Collections.singletonMap("Cache-Control", "no-store"), new ByteArrayInputStream(data.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }
    private static WebResourceResponse failure(int code, String status) {
        return new WebResourceResponse("text/plain", "UTF-8", code, status, Collections.emptyMap(),
            new ByteArrayInputStream(status.getBytes(java.nio.charset.StandardCharsets.UTF_8)));
    }
    static String mimeOf(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".html")) return "text/html";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".js")) return "text/javascript";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".jpg") || n.endsWith(".jpeg")) return "image/jpeg";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".gif")) return "image/gif";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".pdf")) return "application/pdf";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".eml")) return "message/rfc822";
        if (n.endsWith(".txt") || n.endsWith(".md") || n.endsWith(".csv") || n.endsWith(".tsv")) return "text/plain";
        return "application/octet-stream";
    }

    private void toast(String message) { runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show()); }

    public final class NativeExports {
        @JavascriptInterface public synchronized String begin(String filename, String mime, long size, String mode, String to, String message) {
            if (filename == null || mime == null || mode == null || to == null || message == null) return "";
            if (writing != null || pendingSave != null || size < 0 || size > MAX_EXPORT_BYTES) return "";
            if (!"share".equals(mode) && !"save".equals(mode)) return "";
            ExportSession s = new ExportSession();
            s.token = UUID.randomUUID().toString();
            s.fileName = filename.replaceAll("[\\\\/\\p{Cntrl}]", "_");
            if (s.fileName.length() > 140) s.fileName = s.fileName.substring(s.fileName.length() - 140);
            if (s.fileName.trim().isEmpty()) s.fileName = "formatlab.bin";
            s.mime = mimeOf(s.fileName); // Do not trust an arbitrary JS-provided MIME.
            s.size = size;
            s.mode = mode;
            s.recipient = to.length() <= 254 && to.matches("(?i)^[a-z0-9._%+\\-]+@[a-z0-9.\\-]+\\.[a-z]{2,24}$") ? to : "";
            s.message = message.length() > 2000 ? message.substring(0, 2000) : message;
            try {
                File dir = new File(getCacheDir(), "exports");
                if (!dir.exists() && !dir.mkdirs()) return "";
                s.file = new File(dir, s.token + ".bin");
                s.stream = new FileOutputStream(s.file);
                writing = s;
                return s.token;
            } catch (Exception ex) { Log.e("FormatLab", "Cannot open export", ex); return ""; }
        }
        @JavascriptInterface public synchronized boolean chunk(String token, String b64) {
            ExportSession s = writing;
            if (s == null || !s.token.equals(token) || b64.length() > 135000) return false;
            try {
                byte[] bytes = Base64.decode(b64, Base64.DEFAULT);
                if (bytes.length > MAX_CHUNK_BYTES || bytes.length > s.size - s.written) return false;
                s.stream.write(bytes);
                s.written += bytes.length;
                return true;
            } catch (Exception ex) { return false; }
        }
        @JavascriptInterface public synchronized boolean finish(String token) {
            ExportSession s = writing;
            if (s == null || !s.token.equals(token)) return false;
            try { s.stream.close(); } catch (Exception ex) { cancel(token); return false; }
            writing = null;
            if (s.written != s.size) { s.file.delete(); return false; }
            if ("save".equals(s.mode)) {
                pendingSave = s;
                mainHandler.post(() -> {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(s.mime);
                    intent.putExtra(Intent.EXTRA_TITLE, s.fileName);
                    try { startActivityForResult(intent, SAVE_FILE); }
                    catch (Exception ex) { pendingSave = null; s.file.delete(); toast("Mentési ablak nem érhető el."); }
                });
            } else {
                mainHandler.post(() -> share(s));
            }
            return true;
        }
        @JavascriptInterface public synchronized void cancel(String token) {
            if (writing == null || !writing.token.equals(token)) return;
            try { writing.stream.close(); } catch (Exception ignored) { }
            writing.file.delete();
            writing = null;
        }
    }

    private void share(ExportSession s) {
        Uri uri = ExportProvider.uriFor(s.token, s.fileName);
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType(s.mime);
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.putExtra(Intent.EXTRA_SUBJECT, "FormatLab: " + s.fileName);
        if (!s.message.isEmpty() || !s.recipient.isEmpty()) {
            intent.putExtra(Intent.EXTRA_TEXT, s.message);
        }
        if (!s.recipient.isEmpty()) intent.putExtra(Intent.EXTRA_EMAIL, new String[]{s.recipient});
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.setClipData(ClipData.newRawUri("FormatLab export", uri));
        try { startActivity(Intent.createChooser(intent, "Megosztás / e-mail")); }
        catch (Exception ex) { toast("Nincs telepített megosztó alkalmazás."); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILES) {
            ValueCallback<Uri[]> callback = fileCallback;
            fileCallback = null;
            if (callback == null) return;
            if (resultCode != RESULT_OK || data == null) { callback.onReceiveValue(null); return; }
            ArrayList<Uri> uris = new ArrayList<>();
            if (data.getClipData() != null) {
                ClipData clip = data.getClipData();
                for (int i=0; i<Math.min(20, clip.getItemCount()); i++) {
                    Uri u=clip.getItemAt(i).getUri();
                    if (u != null && "content".equals(u.getScheme())) uris.add(u);
                }
            } else if (data.getData() != null && "content".equals(data.getData().getScheme())) uris.add(data.getData());
            callback.onReceiveValue(uris.isEmpty() ? null : uris.toArray(new Uri[0]));
        } else if (requestCode == SAVE_FILE) {
            ExportSession s = pendingSave;
            pendingSave = null;
            if (s == null) return;
            Uri uri = data == null ? null : data.getData();
            if (resultCode != RESULT_OK || uri == null || !"content".equals(uri.getScheme())) { s.file.delete(); return; }
            new Thread(() -> {
                boolean ok = false;
                try (InputStream in = new FileInputStream(s.file); OutputStream out = getContentResolver().openOutputStream(uri, "w")) {
                    if (out == null) throw new IllegalStateException("Unable to open document");
                    byte[] buf = new byte[64 * 1024]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                    ok = true;
                } catch (Exception e) { Log.e("FormatLab", "Save failed", e); }
                s.file.delete();
                toast(ok ? "Fájl mentve." : "A fájl mentése nem sikerült.");
            }, "formatlab-save").start();
        }
    }

    private void clearOldExports() {
        File dir = new File(getCacheDir(), "exports");
        File[] all = dir.listFiles();
        if (all == null) return;
        long olderThan = System.currentTimeMillis() - 24L * 3600 * 1000;
        for (File f : all) if (f.isFile() && f.lastModified() < olderThan) f.delete();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
