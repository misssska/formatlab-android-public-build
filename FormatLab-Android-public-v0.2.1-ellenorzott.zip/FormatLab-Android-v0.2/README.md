# FormatLab Android – offline alkalmazás, v0.2 (public build source)

Ez a **FormatLab v7 privát staging** webes felületéből épülő **Android Studio-forrásprojekt**.
Nem egy APK: APK-fordításhoz Android SDK és Gradle szükséges, ezek a jelenlegi előállítási környezetben nem voltak elérhetők.

> This public source version was specifically reviewed for accidental secrets. See [PUBLIC_SECURITY_AUDIT.md](PUBLIC_SECURITY_AUDIT.md). Do not upload credentials or signing keys.

## Funkciók az Android alkalmazásban

- Telefonon, internet nélkül működő PNG/JPG/WebP konverzió (PNG, JPG, WebP, GIF-első képkocka, BMP, korlátozott SVG bemenettel).
- TXT/Markdown/HTML és CSV/TSV/JSON konvertálás, több fájl és ZIP.
- Android fájlválasztó (Storage Access Framework); letöltés és ZIP mentése a telefonra.
- Android megosztási panel: csatolmány + címzettmező + szöveg. Kiválasztott levelezőben lehet ténylegesen elküldeni; **nem automatikus e-mailküldés**.
- `.eml` csatolmányos e-mailtervezet mentése.
- HU/EN kezelőfelület, az eredeti FormatLab v7 dizájnjával.
- **Nincs INTERNET-engedély, nem tölti fel a fájlokat, nincs aktív reklám**.

**Nem használható offline:** PDF, Word, Excel, PowerPoint, videó, hang és professzionális kép→SVG vektorizálás. A v7 szerveres feldolgozója nem került az APK-ba. Ezeknek a kezelőfelülete látható, de le van tiltva. Vektorizálást, OCR-t vagy natív Office-konverziót az alkalmazás nem állít elő.

## APK építése Android Studióban

1. Telepítsd az Android Studio kompatibilis stabil kiadását JDK 17-tel, Android SDK 35-tel.
2. **File → Open**: nyisd meg a `FormatLab-Android` mappát.
3. Várd meg a Gradle Sync befejezését (első alkalommal internet szükséges a fejlesztőgépen).
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. A telepíthető debug APK: `app/build/outputs/apk/debug/app-debug.apk`.
6. Másold az APK-t Android 8.0+ telefonra, és telepítsd. Ha a telefon kéri, engedélyezd az APK-t megnyitó alkalmazásnak az ismeretlen alkalmazások telepítését.

Alternatív automatizált build: a repót GitHubra feltöltve a **Actions → Android debug APK → Run workflow** futtatás után az Artifactoknál letölthető az APK. A GitHub Actions workflow a projekt része. Ezt a workflow-t ebben a környezetben még **nem** futtattam.

**CLI:** ha a Gradle 8.10.2 és Android SDK 35 telepítve van, a gyökérkönyvtárban `gradle :app:assembleDebug`. A debug APK nem alkalmas üzleti Google Play kiadásra: ahhoz kiadási aláírás, alkalmazásazonosító/dokumentáció, szabályzati ellenőrzés és Play Console kell.

## Műszaki felépítés és biztonság

- Android Java WebView, csomagolt statikus HTML/CSS/JS.
- Lokális HTTPS-szerű origin: `https://appassets.androidplatform.net/`; nincs `file://` WebView futtatás.
- A webes UI fájlokat kizárólag az APK belső assets gyökeréből szolgálja ki. Nincs natív INTERNET-engedély vagy külső tartalom beengedve az alkalmazás WebView-jába.
- Android System File Picker; nincs széleskörű tárolóhozzáférési engedély.
- A mentés 64 KiB-os darabokban jut át a JavaScript ↔ Android hídon. Egy fájl mentési felső határa 150 MiB.
- Az ideiglenes export belső app-cache-ben van. A megosztás read-only, URI-engedélyhez kötött ContentProviderrel történik. A 24 óránál régebbi exportokat a következő indításkor töröljük.
- Nem csomagoltunk bele AdSense-t vagy SMTP titkos adatokat.

## Ellenőrzés és korlátok

`python3 scripts/verify_android.py` — forrásintegritási és offline konfigurációs ellenőrzés.

Ez **forráskiadás**. A natív APK buildet, Android eszközös fájlválasztást, valós telefonos fájlmentést/megosztást és Android WebView működését tényleges eszközön még ellenőrizni kell. A v7 webes tesztjei nem helyettesítik ezt. Az első APK telepítése után a következő elfogadási próba javasolt:

- PNG → JPG és WebP, fájl mentése és megnyitása a Fájlok alkalmazásban.
- CSV → JSON, több konverzió → ZIP.
- Címzett és kísérőszöveg megadása → Android megosztási panel → e-mail-appban címzett és csatolmány ellenőrzése.
- Repülőgép mód: böngészőkonverzió működik, PDF/DOCX konverzió tiltott.
- Több nagyobb fájl és megszakított fájlmentés: hibakezelés, ideiglenes fájlok törlése.

## v0.2 javítások és eredmények

- Offline `blob:` fájlmentési biztonsági szabály, e-mail tárgy/szöveg elkülönítése, szerveres rész helyes offline letiltása és natív mentési szálkezelés.
- Lefutott a 22 oldalas statikus kontroll, a JS-híd teszt és a tényleges PNG→WebP/ZIP/e-mail felhasználói útvonal böngészős tesztje **mockolt Android-híddal**.
- A korábbi, belső buildjelentést nem tettük nyilvánossá; az ellenőrzött publikus jelentés: `PUBLIC_SECURITY_AUDIT.md`.
- **Ebben a csomagban továbbra sincs APK.** Android SDK és Gradle hiányában a natív build blokkolt.
- Windows-os buildsegéd: `scripts/build-debug-windows.ps1`; az Android Studio vagy a meglévő GitHub Actions munkafolyamat is használható.
