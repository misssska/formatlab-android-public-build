#!/usr/bin/env python3
"""Fail closed on accidental private config, secrets, or network regressions."""
from pathlib import Path
import re,sys
r=Path(__file__).resolve().parents[1]
errors=[]
for p in sorted(r.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(r).as_posix()
    if rel=='scripts/audit_public_source.py': continue  # This audit contains example detection signatures.
    if any(n in p.parts for n in ('.git','.gradle','.idea','node_modules')):continue
    if p.name in ('local.properties','.env','.env.local','.env.production','id_rsa','id_ed25519') or p.suffix.lower() in ('.jks','.keystore','.p12','.pfx','.pem','.key'):
        errors.append(f'Forbidden sensitive file: {rel}')
    if p.suffix.lower() not in ('.java','.js','.html','.md','.css','.xml','.yml','.yaml','.gradle','.properties','.py','.json','.txt','.ps1','.gitignore'):continue
    text=p.read_text(encoding='utf-8',errors='replace')
    if re.search(r'-----BEGIN (?:RSA|EC|OPENSSH|DSA|PRIVATE) PRIVATE KEY-----|-----BEGIN PRIVATE KEY-----',text):
        errors.append(f'Embedded PEM key: {rel}')
    if re.search(r'(?i)(?:password|api[_-]?key|client[_-]?secret|access[_-]?token|smtp[_-]?password)\s*[=:]\s*["\']?[a-z0-9+/_.-]{16,}',text):
        errors.append(f'Possible hardcoded credential: {rel}')
    if re.search(r'\b(?:ghp_|gho_|ghu_|ghs_|github_pat_|sk-proj-|sk_live_|AKIA)[A-Za-z0-9_-]{10,}',text):
        errors.append(f'Provider token pattern: {rel}')
manifest=(r/'app/src/main/AndroidManifest.xml').read_text()
if re.search(r'<uses-permission\b',manifest) or 'android:usesCleartextTraffic="false"' not in manifest or 'android:exported="false"' not in manifest:
    errors.append('Offline permissions or secure manifest flags changed')
assets=r/'app/src/main/assets/site'
for name in ('email.js',):
    if (assets/'assets'/name).exists():errors.append('Unneeded online email API code shipped')
for p in assets.rglob('*.html'):
    html=p.read_text()
    if "connect-src 'self' blob:;" not in html:
        errors.append(f'CSP regression: {p.relative_to(r)}')
if errors:
    print('PUBLIC SOURCE AUDIT FAIL:\n'+'\n'.join(errors));sys.exit(1)
print('PASS: public archive denylist, token patterns, offline manifest, CSP and removed online email API')
