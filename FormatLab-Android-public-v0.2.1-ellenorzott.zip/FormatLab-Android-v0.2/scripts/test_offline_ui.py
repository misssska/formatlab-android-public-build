#!/usr/bin/env python3
"""Browser interaction tests of packaged UI using an inline, network-free fixture.
Does not assert Android OS WebView or Java code behaviour.
"""
from io import BytesIO
from pathlib import Path
import re
from PIL import Image
from playwright.sync_api import sync_playwright

site = Path(__file__).resolve().parents[1] / 'app/src/main/assets/site'
init = '''
window.__nativeCalls={begins:[],chunks:0,finishes:[],cancels:[]};
window.FormatLabNative={
 begin:(name,mime,size,mode,to,msg)=>{window.__nativeCalls.begins.push({name,mime,size,mode,to,msg});return 'test-token';},
 chunk:(token,b64)=>{window.__nativeCalls.chunks++;return token==='test-token'&&b64.length<=135000;},
 finish:(token)=>{window.__nativeCalls.finishes.push(token);return true;},
 cancel:(token)=>window.__nativeCalls.cancels.push(token)
};
'''

def inline_page(relative):
    """Resolve the app's own JS/CSS into inline tags, bypassing network policy in this test only."""
    path=site/relative
    html=path.read_text()
    # The tested, packaged content has CSP meta. This harness cannot emulate the Android HTTPS origin.
    # CSP is tested separately on original HTML; remove the meta only from the inline fixture.
    html=re.sub(r'<meta http-equiv="Content-Security-Policy"[^>]*>', '', html, flags=re.I)
    def css_replace(m):
        href=m.group(1)
        css=(path.parent/href).read_text()
        return '<style>\n'+css+'\n</style>'
    html=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',css_replace,html)
    def js_replace(m):
        src=m.group(1)
        js=(path.parent/src).read_text()
        return '<script>\n'+(js.replace("const flag = window.location.pathname.toLowerCase().includes('/converter/');", "const flag = true;") if relative.endswith('converter/index.html') and src.endswith('android-bridge.js') else js)+'\n</script>'
    html=re.sub(r'<script\s+src="([^"]+)"\s+defer></script>',js_replace,html)
    return html

with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    context=browser.new_context(viewport={'width':412,'height':915},is_mobile=True,has_touch=True,accept_downloads=True)
    page=context.new_page()
    errors=[]
    page.on('pageerror',lambda err: errors.append(str(err)))
    page.evaluate(init)
    page.set_content(inline_page('index.html'))
    page.get_by_text('Android offline verzió',exact=False).first.wait_for(timeout=10000)
    img=Image.new('RGB',(48,32),(35,210,155));buf=BytesIO();img.save(buf,format='PNG')
    page.locator('#fileInput').set_input_files({'name':'teszt.png','mimeType':'image/png','buffer':buf.getvalue()})
    page.locator('#convertBtn').click()
    page.locator('.file-status.ready').wait_for(timeout=10000)
    page.locator('.file-item a[download]').click()
    page.wait_for_function('window.__nativeCalls.finishes.length===1',timeout=10000)
    calls=page.evaluate('window.__nativeCalls')
    assert calls['begins'][0]['mode']=='save', calls
    assert calls['begins'][0]['name']=='teszt.webp', calls
    assert calls['chunks']>=1, calls
    page.locator('.share-input[type=email]').fill('user@example.com')
    page.locator('.share-form textarea').fill('Csatoltam a kész képet.')
    page.get_by_role('button',name='Megosztás alkalmazással').click()
    page.wait_for_function('window.__nativeCalls.finishes.length===2',timeout=10000)
    calls=page.evaluate('window.__nativeCalls')
    assert calls['begins'][1]['mode']=='share' and calls['begins'][1]['to']=='user@example.com', calls
    assert 'Csatoltam' in calls['begins'][1]['msg'], calls
    page.locator('#zipBtn').click()
    page.wait_for_function('window.__nativeCalls.finishes.length===3',timeout=10000)
    assert page.evaluate('window.__nativeCalls.begins[2].name').endswith('.zip')
    assert not errors,errors
    # New HTML runs with another fresh document; native bridge reinjected because no navigation used.
    page.evaluate(init)
    page.set_content(inline_page('converter/index.html'))
    assert page.locator('#c3Submit').is_disabled()
    assert page.locator('#c3Input').is_disabled()
    assert 'Offline' in page.locator('#c3Server').inner_text()
    assert not errors,errors
    print('PASS: offline mobile Chromium UI: PNG→WebP, native save, attached email sharing, ZIP, server offline gating; zero JS exceptions')
    browser.close()
