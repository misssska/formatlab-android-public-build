#!/usr/bin/env python3
"""Regression reproducer for CSP blob: fetch used by Android WebView save adapter."""
from playwright.sync_api import sync_playwright

def probe(browser, allowed):
    page=browser.new_page()
    src="default-src 'none'; connect-src 'self'"+(" blob:" if allowed else "")+";"
    page.set_content(f'<meta http-equiv="Content-Security-Policy" content="{src}"><p>FormatLab CSP test</p>')
    result=page.evaluate('''async()=>{
      const url=URL.createObjectURL(new Blob(['FormatLab-OK']));
      try {return (await fetch(url)).text()} catch(e){return 'BLOCKED'} finally{URL.revokeObjectURL(url)}
    }''')
    page.close()
    return result

with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True)
    assert probe(b,False)=='BLOCKED'
    assert probe(b,True)=='FormatLab-OK'
    print('PASS: Chromium CSP without blob: BLOCKS native save fetch; v0.2 connect-src blob: ALLOWS it')
    b.close()
