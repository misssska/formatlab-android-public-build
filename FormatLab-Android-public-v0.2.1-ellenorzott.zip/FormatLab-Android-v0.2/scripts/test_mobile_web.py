#!/usr/bin/env python3
"""Chromium UI smoke of the packaged HTML with fake Android JS bridge.
This does NOT test the native Java implementation; use Android emulator/device for that.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image
from io import BytesIO
import tempfile
import shutil
import os

ROOT=Path(__file__).resolve().parents[1]/'app/src/main/assets/site'
base="https://appassets.androidplatform.net"
try:
    with sync_playwright() as p:
        browser_path=os.environ.get('FORMATLAB_CHROMIUM') or shutil.which('chromium')
        opts={'executable_path':browser_path} if browser_path else {}
        browser=p.chromium.launch(headless=True,**opts)
        context=browser.new_context(viewport={'width':412,'height':915},is_mobile=True,has_touch=True)
        context.add_init_script('''
          window.__nativeCalls={begins:[],chunks:0,finishes:[],cancels:[]};
          window.FormatLabNative={
            begin:(name,mime,size,mode,to,msg)=>{
              window.__nativeCalls.begins.push({name,mime,size,mode,to,msg}); return 'test-uuid';
            },
            chunk:(token,b64)=>{window.__nativeCalls.chunks++;return token==='test-uuid' && b64.length<=135000;},
            finish:(token)=>{window.__nativeCalls.finishes.push(token);return true;},
            cancel:(token)=>window.__nativeCalls.cancels.push(token)
          };
        ''')
        # Supply the whole web origin through Playwright interception; no network connection.
        def local_asset(route):
            from urllib.parse import urlsplit, unquote
            path=unquote(urlsplit(route.request.url).path).lstrip('/') or 'index.html'
            if path.endswith('/'): path+='index.html'
            f=(ROOT/path).resolve()
            if not f.is_relative_to(ROOT.resolve()) or not f.is_file():
                route.fulfill(status=404,body='not found')
            else:
                import mimetypes
                mime=mimetypes.guess_type(str(f))[0] or 'application/octet-stream'
                route.fulfill(status=200,body=f.read_bytes(),headers={'content-type':mime})
        context.route('https://appassets.androidplatform.net/**',local_asset)
        page=context.new_page()
        errors=[]
        page.on('pageerror', lambda err: errors.append(str(err)))
        page.goto(base+'/index.html', wait_until='networkidle')
        assert page.get_by_text('Android offline verzió',exact=False).count()==1
        # basic image conversion from Android picked file -> native save.
        image=Image.new('RGB',(48,32),color=(35,210,155))
        temp=BytesIO(); image.save(temp,format='PNG')
        page.locator('#fileInput').set_input_files({'name':'teszt.png','mimeType':'image/png','buffer':temp.getvalue()})
        page.locator('#convertBtn').click()
        page.locator('.file-status.ready').wait_for(timeout=12000)
        page.locator('.file-item a[download]').click()
        page.wait_for_function('window.__nativeCalls.finishes.length===1',timeout=10000)
        calls=page.evaluate('window.__nativeCalls')
        assert calls['begins'][0]['name']=='teszt.webp',calls
        assert calls['begins'][0]['mode']=='save'
        assert calls['chunks']>=1
        # native share: recipient + custom message and image attachment
        page.locator('.share-input[type=email]').fill('user@example.com')
        page.locator('.share-form textarea').fill('Csatoltam a kész képet.')
        page.get_by_role('button',name='Megosztás alkalmazással').click()
        page.wait_for_function('window.__nativeCalls.finishes.length===2',timeout=10000)
        calls=page.evaluate('window.__nativeCalls')
        assert calls['begins'][1]['mode']=='share',calls
        assert calls['begins'][1]['to']=='user@example.com'
        assert 'Csatoltam' in calls['begins'][1]['msg']
        # ZIP export via intercepted programmatic anchor click.
        page.locator('#zipBtn').click()
        page.wait_for_function('window.__nativeCalls.finishes.length===3',timeout=12000)
        assert page.evaluate('window.__nativeCalls.begins[2].name').endswith('.zip')
        # Server page genuinely offline and conversion controls disabled.
        page.goto(base+'/converter/index.html',wait_until='networkidle')
        assert page.locator('#c3Submit').is_disabled()
        assert page.locator('#c3Input').is_disabled()
        assert 'Offline' in page.locator('#c3Server').inner_text()
        # English page navigation.
        page.goto(base+'/en/index.html',wait_until='networkidle')
        assert page.get_by_text('Android offline edition',exact=False).count()==1
        assert not errors,errors
        print('PASS mobile Chromium: PNG->WebP, native file save, ZIP, share text/recipient, offline server gating, HU/EN, zero JS errors')
        browser.close()
finally:
    pass
