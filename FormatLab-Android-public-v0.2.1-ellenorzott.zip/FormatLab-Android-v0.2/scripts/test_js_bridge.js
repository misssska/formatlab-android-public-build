'use strict';
// Native export protocol unit test. This does not execute native Android Java.
const fs=require('fs');
const path=require('path');
const vm=require('vm');
const assert=require('assert').strict;
const js=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/site/assets/android-bridge.js'),'utf8');
const calls=[];
class Reader {
  readAsDataURL(blob) {
    blob.arrayBuffer().then(data=>{
      this.result='data:application/octet-stream;base64,'+Buffer.from(data).toString('base64');
      this.onload();
    }).catch(err=>this.onerror(err));
  }
}
const collected=[];
const mock={
  begin:(name,mime,size,mode,to,message)=>{calls.push({name,mime,size,mode,to,message});return 'token';},
  chunk:(token,b64)=>{assert.equal(token,'token');const bytes=Buffer.from(b64,'base64');assert.ok(bytes.length<=65536);collected.push(bytes);return true;},
  finish:token=>{assert.equal(token,'token');return true;},
  cancel:token=>{throw Error('Unexpected cancel '+token);}
};
const document={documentElement:{lang:'hu'},getElementById:()=>null,addEventListener:()=>{}};
const window={FormatLabNative:mock, location:{pathname:'/about/index.html'}};
vm.runInNewContext(js,{window, document, Blob, FileReader:Reader, Buffer, console});
(async()=>{
  const bytes=Buffer.alloc(160000);
  for(let i=0;i<bytes.length;i++)bytes[i]=(i*17)%251;
  await window.FormatLabAndroid.saveBlob(new Blob([bytes],{type:'image/png'}),'test.png');
  assert.equal(calls[0].mode,'save');
  assert.equal(calls[0].size,160000);
  assert.equal(collected.length,3);
  assert.deepEqual(Buffer.concat(collected),bytes);
  collected.length=0;
  await window.FormatLabAndroid.shareBlob(new Blob([bytes.slice(0,5000)]),'test.webp','user@example.com','Üzenet');
  assert.equal(calls[1].mode,'share');
  assert.equal(calls[1].to,'user@example.com');
  assert.equal(calls[1].message,'Üzenet');
  assert.deepEqual(Buffer.concat(collected),bytes.slice(0,5000));
  console.log('PASS: Android JS bridge 64-KiB chunks, exact bytes, local save, email share with recipient and body');
})().catch(err=>{console.error(err);process.exitCode=1;});
