# v0.3 validation checkpoint

## Completed locally

- Source-level privacy and CSP audit: PASS.
- 23 HTML pages/local references and 5 JS syntax checks: PASS.
- Android existing native exports JavaScript unit test: PASS.
- Offline BMP and TIFF header+decode smoke: PASS with Pillow.
- SVG actual vector path content and plotter-path smoke: PASS with XML parser.
- Native v0.3 source contract and file format matrix checks: PASS.

## Not yet verified

- Real APK compile against Android SDK 35 in GitHub Actions: PENDING.
- Runtime native framework PDF/DOCX/MP4 outputs on Android phone: PENDING.
- DOCX/PDF layout fidelity beyond plain-text extraction: NOT SUPPORTED.
- Full browser E2E test in this environment: BLOCKED (Chromium local HTTP/file/data URLs return ERR_BLOCKED_BY_ADMINISTRATOR).

## Next gates

1. SHA-pinned source ZIP upload to public build repository.
2. GitHub APK build PASS and release asset available.
3. Device install upgrade from v0.2.1 and save/share/regression tests.
4. PDF→ZIP, DOCX→PDF, picture→SVG and AAC→M4A manual acceptance tests on real files.
