#!/usr/bin/env python3
"""Surface contract only: does not claim Android bytecode has compiled or app passed handset tests."""
from pathlib import Path
import xml.etree.ElementTree as ET
R=Path(__file__).resolve().parents[1]
S=R/'app/src/main/assets/site'
page=(S/'offline/index.html').read_text()
js=(S/'assets/offline.js').read_text()
java=(R/'app/src/main/java/hu/formatlab/android/OfflineDocuments.java').read_text()
main=(R/'app/src/main/java/hu/formatlab/android/MainActivity.java').read_text()
manifest=(R/'app/src/main/AndroidManifest.xml').read_text()
assert "'none'" in page and 'offline.js' in page and 'android-bridge.js' in page
assert 'android-bridge.js' in page[:page.index('offline.js')]
assert 'FormatLabAndroid.saveBlob' in js and 'FormatLabAndroid.shareBlob' in js
assert 'pngzip' in js and 'jpgzip' in js and 'pdfPageZip' in java
assert 'extractDocx' in java and 'textToPdf' in java and 'textToDocx' in java
assert 'MediaExtractor' in java and 'MediaMuxer' in java and 'audio/mp4a-latm' in java
assert 'MAX_INPUT = 6 * 1024 * 1024' in java
assert 'MAX_PIXELS = 10_000_000' in java
assert 'new OfflineDocuments(this)' in main
assert 'if (n.endsWith(".tif")' in main and 'if (n.endsWith(".docx")' in main
assert 'android.permission.INTERNET' not in manifest
assert 'android.permission.READ_EXTERNAL_STORAGE' not in manifest
assert 'android.permission.WRITE_EXTERNAL_STORAGE' not in manifest
assert 'versionCode 3' in (R/'app/build.gradle').read_text()
assert 'versionName \'0.3.0\'' in (R/'app/build.gradle').read_text()
ET.parse(R/'app/src/main/AndroidManifest.xml')
print('PASS: offline v0.3 UI, native bridge, document/media engine, limits, manifest, version')
