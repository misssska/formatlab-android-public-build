const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements={};function el(id){if(!elements[id])elements[id]={value:'',style:{},hidden:false,disabled:false,textContent:'',append(){},replaceChildren(){},addEventListener(){},setAttribute(){},getAttribute(){return null}};return elements[id];}
const window={};const document={getElementById:el};
vm.runInNewContext(fs.readFileSync(__dirname+'/../app/src/main/assets/site/assets/offline.js','utf8'),{
  window,document,Blob,TextEncoder,TextDecoder,Uint8Array,DataView,URL,FileReader:function(){},Image:function(){},setTimeout,clearTimeout,DOMParser:function(){},console
});
const {bmpEncode,tiffEncode,contourPaths,thin,skeletonPaths}=window.FormatLabOfflineTest;
let pixels=new Uint8ClampedArray(4*4*4).fill(255);pixels[0]=0;pixels[1]=0;pixels[2]=0;
const bmp=bmpEncode(pixels,4,4),tiff=tiffEncode(pixels,4,4);
assert.equal(bmp.type,'image/bmp');assert.equal(tiff.type,'image/tiff');
(async()=>{
 let b=new DataView(await bmp.arrayBuffer()),t=new DataView(await tiff.arrayBuffer());
 assert.equal(b.getUint16(0,true),0x4d42);assert.equal(b.getUint32(2,true),bmp.size);
 assert.equal(t.getUint16(2,true),42);assert.equal(t.getUint32(4,true),8+4*4*3);
 let mask=new Uint8Array(100);for(let y=2;y<8;y++)for(let x=2;x<8;x++)mask[y*10+x]=1;
 let paths=contourPaths(mask,10,10,false);assert(paths.length>=1);assert(paths.some(s=>s.includes(' Z')));
 let skeleton=thin(mask,10,10),p=skeletonPaths(skeleton,10,10);assert(skeleton.reduce((a,b)=>a+b,0)<mask.reduce((a,b)=>a+b,0));
 console.log('PASS: BMP headers, TIFF headers, SVG vector contours, plotter thinning', {contours:paths.length,plotterPaths:p.length});
})().catch(e=>{console.error(e);process.exit(1)});
