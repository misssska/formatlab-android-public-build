#!/usr/bin/env python3
"""Source-level tests. NOT a substitute for an Android SDK build or device testing."""
from pathlib import Path
import re, sys, subprocess, xml.etree.ElementTree as ET
from urllib.parse import urlsplit, unquote
R = Path(__file__).resolve().parents[1]
SITE = R/'app/src/main/assets/site'
files = list(SITE.rglob('*.html'))
assert len(files) == 23, f'expected 23 HTML pages, got {len(files)}'
assert (SITE/'assets/android-bridge.js').is_file()
assert not (SITE/'api').exists()
manifest=R/'app/src/main/AndroidManifest.xml'
mt=manifest.read_text()
assert 'android.permission.INTERNET' not in mt
assert 'android.permission.READ_EXTERNAL_STORAGE' not in mt
assert 'android:usesCleartextTraffic="false"' in mt
assert 'android:grantUriPermissions="true"' in mt
assert 'android:exported="false"' in mt
ET.parse(manifest)
for file in files:
    s=file.read_text()
    assert s.count('android-bridge.js')==1, file
    assert 'email.js' not in s, file
    assert 'http-equiv="Content-Security-Policy"' in s, file
    assert "connect-src 'self' blob:;" in s, f'Android blob save requires explicit connect-src blob: in {file}'
    assert "connect-src *" not in s, f'Unexpected network-wide CSP in {file}'
    # check actual source src/href for local static asset references
    for value in re.findall(r'(?:src|href)=["\']([^"\']+)["\']',s):
        if not value or value.startswith(('#','data:','blob:','mailto:','http:','https:')): continue
        path=urlsplit(value).path
        if path.startswith('/'):
            resolved=(SITE/path.lstrip('/')).resolve()
        else:
            resolved=(file.parent/path).resolve()
        assert resolved.is_relative_to(SITE.resolve()), (file,value)
        assert resolved.exists(), (file.relative_to(SITE),value)
for f in (SITE/'assets').glob('*.js'):
    result=subprocess.run(['node','--check',str(f)],capture_output=True,text=True)
    assert result.returncode==0, f'{f}: {result.stderr}'
for file in [R/'app/src/main/java/hu/formatlab/android/MainActivity.java',R/'app/src/main/java/hu/formatlab/android/ExportProvider.java', R/'app/src/main/java/hu/formatlab/android/OfflineDocuments.java']:
    assert file.read_text().count('{')==file.read_text().count('}'), file
assert 'if (bridge) document.addEventListener' in (SITE/'assets/android-bridge.js').read_text()
assert 'setAllowFileAccess(false)' in (R/'app/src/main/java/hu/formatlab/android/MainActivity.java').read_text()
assert 'MODE_READ_ONLY' in (R/'app/src/main/java/hu/formatlab/android/ExportProvider.java').read_text()
assert 'intent.putExtra(Intent.EXTRA_TEXT, s.message);' in (R/'app/src/main/java/hu/formatlab/android/MainActivity.java').read_text()
assert 'private volatile ExportSession pendingSave;' in (R/'app/src/main/java/hu/formatlab/android/MainActivity.java').read_text()
assert 'if(window.FormatLabNative){' in (SITE/'assets/converter.js').read_text()
assert 'webView.addJavascriptInterface(new OfflineDocuments(this), "FormatLabDocuments")' in (R/'app/src/main/java/hu/formatlab/android/MainActivity.java').read_text()
assert 'window.FormatLabOfflineTest' in (SITE/'assets/offline.js').read_text()
print(f'PASS: {len(files)} HTML pages, {len(list((SITE/"assets").glob("*.js")))} JS syntax checks, manifest, offline restrictions and local links')
print('NOTE: Android SDK build and real-device tests still required.')
