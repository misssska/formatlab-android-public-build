# FormatLab Android v0.3 — public source audit

Static inspection and automated checks passed at package creation. This is **not** a third-party security audit.

- No secrets, provider tokens, personal credentials or signing keys are included.
- No Internet permission or external-storage permissions; file access via Storage Access Framework.
- APK saves and shares files via existing scoped native bridge; does not upload them.
- Android WebView restricts network/resource loading and exposes locally packaged JS only.
- Document input, output, PDF pages/pixels, source zip entry count, DOCX XML and media sample count are bounded.
- Potential residual risk: malformed PDF/AVIF/HEIC/media inputs exercise Android OS codecs/parsers in the app process. This prototype is not a hardened isolation process for hostile public uploads.
- Public repository makes all source code visible. APK is debug-signed; not Play Store ready.

## Caveats

Format-specific parsers run within the Android application. A crash of a system decoder can terminate the app. Only install from the project's official release; device verification is outstanding.
