package hu.formatlab.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaCodec;
import java.nio.ByteBuffer;
import java.io.FileInputStream;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import android.util.Base64;
import android.util.Xml;
import android.webkit.JavascriptInterface;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Strictly offline conversion, bounded input/output, no external dependencies or network. */
public final class OfflineDocuments {
    private static final int MAX_INPUT = 6 * 1024 * 1024;
    private static final int MAX_OUTPUT = 16 * 1024 * 1024;
    private static final int MAX_TEXT = 180000;
    private static final int MAX_PIXELS = 10_000_000;
    private final Context context;

    public OfflineDocuments(Context context) { this.context = context.getApplicationContext(); }

    @JavascriptInterface public String convert(String data64, String source, String target) {
        try {
            if (data64 == null || source == null || target == null || data64.length() > (MAX_INPUT * 4 / 3 + 32))
                throw new IllegalArgumentException("Bemeneti fájl túl nagy (max. 6 MB).");
            byte[] data = Base64.decode(data64, Base64.DEFAULT);
            if (data.length == 0 || data.length > MAX_INPUT) throw new IllegalArgumentException("Hibás vagy túl nagy fájl.");
            source = source.toLowerCase(java.util.Locale.ROOT);
            target = target.toLowerCase(java.util.Locale.ROOT);
            byte[] result;
            String mime;
            if ((source.equals("mp4") || source.equals("mov") || source.equals("m4v")) && target.equals("m4a")) {
                result=extractAacAudio(data);
                mime="audio/mp4";
            } else if (source.equals("pdf") && (target.equals("png") || target.equals("jpg") || target.equals("pngzip") || target.equals("jpgzip"))) {
                if(target.endsWith("zip")) {result = pdfPageZip(data,target.startsWith("png") ? "png" : "jpg"); mime = "application/zip";}
                else {result = pdfFirstPage(data, target); mime = target.equals("png") ? "image/png" : "image/jpeg";}
            } else if (source.equals("docx") && (target.equals("txt") || target.equals("pdf"))) {
                String text = extractDocx(data);
                result = target.equals("txt") ? text.getBytes(StandardCharsets.UTF_8) : textToPdf(text);
                mime = target.equals("txt") ? "text/plain" : "application/pdf";
            } else if ((source.equals("txt") || source.equals("md") || source.equals("csv") || source.equals("json")) && (target.equals("pdf") || target.equals("docx"))) {
                String text = cleanText(data);
                result = target.equals("pdf") ? textToPdf(text) : textToDocx(text);
                mime = target.equals("pdf") ? "application/pdf" : "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            } else if (isImage(source) && target.equals("pdf")) {
                result = imageToPdf(data);
                mime = "application/pdf";
            } else if (isImage(source) && (target.equals("png") || target.equals("jpg") || target.equals("webp"))) {
                result = imageToRaster(data, target);
                mime = target.equals("jpg") ? "image/jpeg" : target.equals("png") ? "image/png" : "image/webp";
            } else {
                throw new IllegalArgumentException("Ez a formátumpár offline még nem támogatott.");
            }
            if (result.length == 0 || result.length > MAX_OUTPUT) throw new IllegalArgumentException("A kimenet túl nagy (max. 16 MB).");
            JSONObject object = new JSONObject();
            object.put("ok", true); object.put("mime", mime);
            object.put("data", Base64.encodeToString(result, Base64.NO_WRAP));
            if (source.equals("pdf")) object.put("notice", target.endsWith("zip") ? "PDF-oldalak ZIP-fájlban, legfeljebb 20 oldal. Nem végez OCR-t." : "A PDF-nek csak az első oldala kerül képfájlba.");
            if (source.equals("docx")) object.put("notice", "Egyszerűsített szövegkinyerés. A Word tördelése, képei és táblázatformázása nem marad meg.");
            if (target.equals("m4a")) object.put("notice", "Csak a meglévő AAC hangsáv kerül át M4A-ba, nincs újrakódolás.");
            return object.toString();
        } catch (Exception ex) {
            try { return new JSONObject().put("ok", false).put("error", ex instanceof IllegalArgumentException ? ex.getMessage() : "A dokumentum sérült, nem támogatott vagy túllépte a feldolgozási keretet.").toString(); }
            catch (Exception ignored) { return "{\"ok\":false,\"error\":\"Konvertálási hiba\"}"; }
        } catch (OutOfMemoryError oom) {
            return "{\"ok\":false,\"error\":\"Nincs elég memória a művelethez.\"}";
        }
    }

    private static String cleanText(byte[] data) {
        String s = new String(data, StandardCharsets.UTF_8).replace("\r\n", "\n").replace('\r', '\n');
        if (s.length() > MAX_TEXT) throw new IllegalArgumentException("Legfeljebb 180 000 karakter konvertálható.");
        return s;
    }

    private static byte[] textToPdf(String text) throws Exception {
        if (text.length() > MAX_TEXT) throw new IllegalArgumentException("Túl hosszú dokumentum.");
        PdfDocument pdf = new PdfDocument();
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.BLACK); paint.setTextSize(12); paint.setTypeface(Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL));
        final int pageWidth=595, pageHeight=842, left=40, right=40, top=48, bottom=40, lineHeight=17;
        final int maxCharsPerLine = 67;
        int pageNo=0,y=0; PdfDocument.Page page=null; Canvas canvas=null;
        try {
            String[] lines = text.split("\n", -1);
            for (String line : lines) {
                // Wrap long lines instead of truncating them, preserving all readable text.
                int length=Math.max(1,line.length());
                for(int off=0;off<length;off+=maxCharsPerLine) {
                    if(page==null || y+lineHeight>pageHeight-bottom) {
                        if(page!=null) pdf.finishPage(page);
                        if(++pageNo>120) throw new IllegalArgumentException("Legfeljebb 120 PDF-oldal támogatott.");
                        page=pdf.startPage(new PdfDocument.PageInfo.Builder(pageWidth,pageHeight,pageNo).create());
                        canvas=page.getCanvas(); canvas.drawColor(Color.WHITE); y=top;
                    }
                    String chunk=line.isEmpty()?"":line.substring(off,Math.min(line.length(),off+maxCharsPerLine));
                    canvas.drawText(chunk,left,y,paint);
                    y+=lineHeight;
                }
            }
            if(page!=null) pdf.finishPage(page);
            ByteArrayOutputStream out=new ByteArrayOutputStream(); pdf.writeTo(out); return out.toByteArray();
        } finally { pdf.close(); }
    }

    private static String extractDocx(byte[] bytes) throws Exception {
        byte[] xml=null; int total=0, count=0;
        try (ZipInputStream zip=new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry e;
            while((e=zip.getNextEntry())!=null) {
                if(++count>250) throw new IllegalArgumentException("Túl sok elem a DOCX-fájlban.");
                if(e.getName().equals("word/document.xml")) {
                    ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
                    while((n=zip.read(buf))!=-1){total+=n;if(total>3_000_000)throw new IllegalArgumentException("A DOCX XML túl nagy.");out.write(buf,0,n);}
                    xml=out.toByteArray(); break;
                }
            }
        }
        if(xml==null)throw new IllegalArgumentException("Nem található a DOCX dokumentumszövege.");
        XmlPullParser parser=Xml.newPullParser(); parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,true);
        parser.setInput(new ByteArrayInputStream(xml),"UTF-8");
        StringBuilder out=new StringBuilder();int depth=0;boolean inText=false;
        while(true){int event=parser.next();if(event==XmlPullParser.END_DOCUMENT)break;
            if(event==XmlPullParser.START_TAG){String tag=parser.getName();
                if(tag.equals("t")) inText=true;
                if(tag.equals("tab")) out.append('\t');
                if(tag.equals("br")) out.append('\n');
            }else if(event==XmlPullParser.TEXT && inText)out.append(parser.getText());
            else if(event==XmlPullParser.END_TAG){String tag=parser.getName();
                if(tag.equals("t"))inText=false;
                if(tag.equals("p"))out.append('\n');
            }
            if(out.length()>MAX_TEXT)throw new IllegalArgumentException("A Word-szöveg túl nagy.");
        }
        return out.toString();
    }

    private static String xmlEscape(String text) { return text.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;"); }
    private static void put(ZipOutputStream zip,String name,String value)throws Exception{
        zip.putNextEntry(new ZipEntry(name));zip.write(value.getBytes(StandardCharsets.UTF_8));zip.closeEntry();
    }
    private static byte[] textToDocx(String text) throws Exception {
        StringBuilder body=new StringBuilder();
        for(String line:text.split("\n",-1)){
            body.append("<w:p><w:r><w:t xml:space=\"preserve\">")
                .append(xmlEscape(line.replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]", "")))
                .append("</w:t></w:r></w:p>");
        }
        ByteArrayOutputStream bytes=new ByteArrayOutputStream();
        try(ZipOutputStream zip=new ZipOutputStream(bytes)){
            put(zip,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>");
            put(zip,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>");
            put(zip,"word/document.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>"+body+"<w:sectPr/></w:body></w:document>");
        }
        return bytes.toByteArray();
    }

    private byte[] extractAacAudio(byte[] data) throws Exception {
        File input=File.createTempFile("formatlab-media-",".mp4",context.getCacheDir());
        File output=File.createTempFile("formatlab-audio-",".m4a",context.getCacheDir());
        MediaExtractor extractor=new MediaExtractor(); MediaMuxer muxer=null;
        boolean started=false;
        try {
            try(FileOutputStream file=new FileOutputStream(input)) {file.write(data);}
            extractor.setDataSource(input.getAbsolutePath());
            int audioIndex=-1;
            MediaFormat audioFormat=null;
            for(int i=0;i<extractor.getTrackCount();i++) {
                MediaFormat format=extractor.getTrackFormat(i);
                String mime=format.getString(MediaFormat.KEY_MIME);
                if("audio/mp4a-latm".equals(mime)) {audioIndex=i;audioFormat=format;break;}
            }
            if(audioIndex<0) throw new IllegalArgumentException("Nincs AAC hangsáv az MP4-ben. Más kodek átkódolása még nem támogatott.");
            extractor.selectTrack(audioIndex);
            muxer=new MediaMuxer(output.getAbsolutePath(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int track=muxer.addTrack(audioFormat);
            muxer.start();started=true;
            ByteBuffer buffer=ByteBuffer.allocateDirect(256*1024);
            MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            long lastTimestamp=-1;
            int samples=0;
            while(samples++<2_000_000) {
                buffer.clear();
                int count=extractor.readSampleData(buffer,0);
                if(count<0) break;
                if(count>buffer.capacity()) throw new IllegalArgumentException("Túl nagy audiominta.");
                long time=extractor.getSampleTime();
                if(time<0) break;
                if(time<lastTimestamp)throw new IllegalArgumentException("Sérült audio-időbélyeg.");
                lastTimestamp=time;
                info.offset=0;info.size=count;info.presentationTimeUs=time;info.flags=extractor.getSampleFlags();
                buffer.position(0);buffer.limit(count);
                muxer.writeSampleData(track,buffer,info);
                if(output.length()>MAX_OUTPUT)throw new IllegalArgumentException("A hangsáv túl nagy.");
                if(!extractor.advance())break;
            }
            if(samples>=2_000_000)throw new IllegalArgumentException("Túl sok audiominta.");
            muxer.stop();started=false;muxer.release();muxer=null;
            if(output.length()==0||output.length()>MAX_OUTPUT)throw new IllegalArgumentException("Üres vagy túl nagy M4A-fájl.");
            try(FileInputStream file=new FileInputStream(output)){
                ByteArrayOutputStream bytes=new ByteArrayOutputStream();byte[] chunk=new byte[8192];int n;
                while((n=file.read(chunk))!=-1){bytes.write(chunk,0,n);if(bytes.size()>MAX_OUTPUT)throw new IllegalArgumentException("A hangsáv túl nagy.");}
                return bytes.toByteArray();
            }
        } finally {
            if(muxer!=null){if(started)try{muxer.stop();}catch(Exception ignored){} try{muxer.release();}catch(Exception ignored){}}
            try{extractor.release();}catch(Exception ignored){}
            input.delete();output.delete();
        }
    }

    private static boolean isImage(String source) {
        return source.equals("png") || source.equals("jpg") || source.equals("webp") || source.equals("gif")
            || source.equals("bmp") || source.equals("heic") || source.equals("avif");
    }

    private static Bitmap decodeBoundedImage(byte[] data) {
        BitmapFactory.Options options=new BitmapFactory.Options(); options.inJustDecodeBounds=true;
        BitmapFactory.decodeByteArray(data,0,data.length,options);
        if(options.outWidth<=0 || options.outHeight<=0 || (long)options.outWidth*options.outHeight>MAX_PIXELS)
            throw new IllegalArgumentException("Túl nagy vagy ezen az Androidon nem támogatott kép.");
        Bitmap image=BitmapFactory.decodeByteArray(data,0,data.length);
        if(image==null) throw new IllegalArgumentException("A készülék képdekódolója nem támogatja ezt a formátumot.");
        return image;
    }

    private static byte[] imageToRaster(byte[] data,String target)throws Exception {
        Bitmap bitmap=decodeBoundedImage(data);
        try {
            Bitmap working=bitmap;
            if(target.equals("jpg")) {
                working=Bitmap.createBitmap(bitmap.getWidth(),bitmap.getHeight(),Bitmap.Config.ARGB_8888);
                Canvas canvas=new Canvas(working);canvas.drawColor(Color.WHITE);canvas.drawBitmap(bitmap,0,0,null);
            }
            try {
                ByteArrayOutputStream stream=new ByteArrayOutputStream();
                Bitmap.CompressFormat format=target.equals("jpg")?Bitmap.CompressFormat.JPEG:
                    target.equals("webp")?Bitmap.CompressFormat.WEBP:Bitmap.CompressFormat.PNG;
                if(!working.compress(format, target.equals("png")?100:88,stream))
                    throw new IllegalArgumentException("Nem sikerült a kép kódolása.");
                return stream.toByteArray();
            } finally {if(working!=bitmap) working.recycle();}
        }finally {bitmap.recycle();}
    }

    private static byte[] imageToPdf(byte[] data)throws Exception{
        Bitmap img=decodeBoundedImage(data);
        PdfDocument pdf=new PdfDocument();
        try{
            PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,1).create());
            Canvas c=page.getCanvas();c.drawColor(Color.WHITE);
            float scale=Math.min(515f/img.getWidth(),762f/img.getHeight());
            float width=img.getWidth()*scale,height=img.getHeight()*scale;
            c.drawBitmap(img,null,new android.graphics.RectF((595-width)/2,(842-height)/2,(595+width)/2,(842+height)/2),new Paint(Paint.FILTER_BITMAP_FLAG));
            pdf.finishPage(page);
            ByteArrayOutputStream out=new ByteArrayOutputStream();pdf.writeTo(out);return out.toByteArray();
        } finally {pdf.close();img.recycle();}
    }

    private byte[] pdfPageZip(byte[] data, String format)throws Exception {
        if(data.length<8 || !(new String(data,0,Math.min(5,data.length),StandardCharsets.US_ASCII)).equals("%PDF-"))
            throw new IllegalArgumentException("Érvénytelen PDF-fejléc.");
        File temp=File.createTempFile("formatlab-pdf-",".pdf",context.getCacheDir());
        try {
            try(FileOutputStream f=new FileOutputStream(temp)){f.write(data);}
            try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(temp,ParcelFileDescriptor.MODE_READ_ONLY);
                PdfRenderer renderer=new PdfRenderer(fd)) {
                int pages=renderer.getPageCount();
                if(pages<1 || pages>20)throw new IllegalArgumentException("PDF→ZIP: maximum 20 oldal.");
                long totalPixels=0;
                ByteArrayOutputStream memory=new ByteArrayOutputStream();
                try(ZipOutputStream zip=new ZipOutputStream(memory)) {
                    for(int i=0;i<pages;i++){
                        try(PdfRenderer.Page page=renderer.openPage(i)) {
                            int width=page.getWidth(),height=page.getHeight();
                            if(width<1 || height<1)throw new IllegalArgumentException("Érvénytelen PDF-oldalméret.");
                            float scale=Math.min(1.6f,Math.min(1900f/width,1900f/height));
                            width=Math.max(1,Math.round(width*scale));height=Math.max(1,Math.round(height*scale));
                            totalPixels+=(long)width*height;
                            if((long)width*height>3_500_000L || totalPixels>30_000_000L)
                                throw new IllegalArgumentException("A PDF-oldalak túl sok képpontot tartalmaznak.");
                            Bitmap bitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
                            try {
                                bitmap.eraseColor(Color.WHITE);
                                page.render(bitmap,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                                zip.putNextEntry(new ZipEntry(String.format(java.util.Locale.ROOT,"page-%03d.%s",i+1,format)));
                                if(!bitmap.compress(format.equals("png")?Bitmap.CompressFormat.PNG:Bitmap.CompressFormat.JPEG,format.equals("png")?100:85,zip))
                                    throw new IllegalStateException("Nem sikerült a PDF-oldalt kódolni.");
                                zip.closeEntry();
                            } finally {bitmap.recycle();}
                            if(memory.size()>MAX_OUTPUT) throw new IllegalArgumentException("A PDF ZIP túllépi a 16 MB-os korlátot.");
                        }
                    }
                }
                return memory.toByteArray();
            }
        } finally {temp.delete();}
    }

    private byte[] pdfFirstPage(byte[] data,String format)throws Exception{
        if(data.length<8 || !(new String(data,0,Math.min(5,data.length),StandardCharsets.US_ASCII)).equals("%PDF-"))
            throw new IllegalArgumentException("Érvénytelen PDF-fejléc.");
        File temp=File.createTempFile("formatlab-pdf-",".pdf",context.getCacheDir());
        try{
            try(FileOutputStream f=new FileOutputStream(temp)){f.write(data);}
            try(ParcelFileDescriptor fd=ParcelFileDescriptor.open(temp,ParcelFileDescriptor.MODE_READ_ONLY);
                PdfRenderer renderer=new PdfRenderer(fd)){
                if(renderer.getPageCount()<1 || renderer.getPageCount()>120)throw new IllegalArgumentException("PDF-oldalszám-korlát: 120.");
                try(PdfRenderer.Page page=renderer.openPage(0)){
                    int width=page.getWidth(),height=page.getHeight();
                    if(width<=0||height<=0)throw new IllegalArgumentException("Hibás PDF-oldalméret.");
                    float scale=Math.min(2.0f,Math.min(2400f/width,2400f/height));
                    width=Math.max(1,Math.round(width*scale));height=Math.max(1,Math.round(height*scale));
                    if((long)width*height>MAX_PIXELS)throw new IllegalArgumentException("A PDF-oldal túl nagy.");
                    Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
                    try{
                        bmp.eraseColor(Color.WHITE);
                        page.render(bmp,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        ByteArrayOutputStream out=new ByteArrayOutputStream();
                        bmp.compress(format.equals("jpg")?Bitmap.CompressFormat.JPEG:Bitmap.CompressFormat.PNG,format.equals("jpg")?88:100,out);
                        return out.toByteArray();
                    }finally{bmp.recycle();}
                }
            }
        }finally{temp.delete();}
    }
}
