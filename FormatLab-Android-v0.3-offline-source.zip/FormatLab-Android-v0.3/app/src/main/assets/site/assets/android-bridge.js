/* FormatLab Android offline edition. Native exports use bounded base64 chunks.
   No files are sent to any web endpoint. */
(() => {
  'use strict';
  const hu = !document.documentElement.lang.toLowerCase().startsWith('en');
  const t = (h,e) => hu ? h : e;
  const bridge = window.FormatLabNative;
  const CHUNK = 64 * 1024;
  const MAX = 150 * 1024 * 1024;
  const flag = window.location.pathname.toLowerCase().includes('/converter/');

  function show(message, bad=false) {
    let bar = document.getElementById('androidStatus');
    if (!bar) {
      bar = document.createElement('p');
      bar.id = 'androidStatus';
      bar.setAttribute('role','status');
      bar.setAttribute('aria-live','polite');
      bar.style.cssText='position:sticky;bottom:0;z-index:99;margin:0;background:#152c3a;color:#d5fff4;padding:14px;font:500 14px/1.4 system-ui;border-top:1px solid #52d8b1;';
      document.body.append(bar);
    }
    bar.style.borderColor = bad ? '#f88989' : '#52d8b1';
    bar.textContent = message;
  }
  function toBase64(blob) {
    return new Promise((resolve,reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(Error(t('Nem olvasható a fájl.','Cannot read file.')));
      reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
      reader.readAsDataURL(blob);
    });
  }
  async function exportBlob(blob, filename, mode, recipient='', message='') {
    if (!bridge) throw Error('Native Android export interface unavailable');
    if (!(blob instanceof Blob) || blob.size > MAX)
      throw Error(t('Maximum 150 MB menthető.','Export limit is 150 MB.'));
    const token = bridge.begin(String(filename), String(blob.type||''), blob.size, mode, String(recipient), String(message));
    if (!token) throw Error(t('A mentés jelenleg foglalt.','An export is already in progress.'));
    try {
      for (let off=0;off<blob.size;off+=CHUNK) {
        const encoded = await toBase64(blob.slice(off, Math.min(off+CHUNK,blob.size)));
        if (!bridge.chunk(token,encoded)) throw Error(t('A fájladatok továbbítása megszakadt.','File transfer interrupted.'));
      }
      if (!bridge.finish(token)) throw Error(t('Hibás fájlméret vagy mentési hiba.','Incorrect file size or save error.'));
    } catch(e) { bridge.cancel(token); throw e; }
  }
  window.FormatLabAndroid = bridge ? {
    saveBlob: (blob,name) => exportBlob(blob,name,'save'),
    shareBlob: (blob,name,to,message) => exportBlob(blob,name,'share',to,message)
  } : undefined;
  // Catch both user-triggered and programmatic <a download> from v7 application code.
  if (bridge) document.addEventListener('click', event => {
    const el = event.target instanceof Element ? event.target.closest('a[download]') : null;
    if (!el || !el.href.startsWith('blob:')) return;
    event.preventDefault();
    event.stopPropagation();
    fetch(el.href).then(r=>{if(!r.ok)throw Error('Blob unavailable');return r.blob();})
      .then(blob => exportBlob(blob,el.download||'formatlab-fajl','save'))
      .then(() => show(t('Válaszd ki, hová mentsük a fájlt.','Choose where to save the file.')))
      .catch(err => show(t('Mentési hiba: ','Save error: ')+String(err.message||err),true));
  },true);

  // This is a real offline edition. Never imply that private staging API can be used on a phone.
  if (flag) {
    const status=document.getElementById('c3Server');
    if(status) status.textContent=t('Offline – szerver szükséges','Offline – server required');
    const alert=document.getElementById('c3Status');
    if(alert) alert.textContent=t(
      'A PDF, DOC/DOCX, videó és professzionális SVG konvertálás szervert igényel, ezért az Android offline kiadásban le van tiltva.',
      'PDF, DOC/DOCX, video and professional SVG conversion need a server and are disabled in this offline Android version.');
    const submit=document.getElementById('c3Submit');if(submit) submit.disabled=true;
    const input=document.getElementById('c3Input');if(input) input.disabled=true;
    const drop=document.getElementById('c3Drop');if(drop){drop.style.pointerEvents='none';drop.style.opacity='.45';}
    // The v7 script may asynchronously update the status/disabled states. Enforce offline mode.
    const observer=new MutationObserver(()=>{
      if(submit && !submit.disabled) submit.disabled=true;
      if(input && !input.disabled) input.disabled=true;
    });
    if(submit) observer.observe(submit,{attributes:true,attributeFilter:['disabled']});
    if(input) observer.observe(input,{attributes:true,attributeFilter:['disabled']});
  } else if(document.getElementById('konvertalo')) {
    const banner=document.createElement('aside');
    banner.style.cssText='max-width:1100px;margin:16px auto;padding:12px 18px;border:1px solid #2c645d;border-radius:12px;color:#bdf5e4;font:14px/1.45 system-ui;background:#122d31;';
    banner.textContent=t('Android offline verzió: képek, szöveg és CSV/JSON helyben konvertálható. Offline PDF, DOCX és SVG az új Offline műhelyben; videó egyelőre nem támogatott.',
      'Android offline edition: images, text and CSV/JSON convert locally. Offline PDF, DOCX and SVG are in the new Offline tools page; video is not yet supported.');
    const root=document.getElementById('konvertalo');root.parentNode.insertBefore(banner,root);
  }
})();
