# FormatLab Android v0.3 — offline alpha

This is an **offline-only Android** prototype derived from the user-tested v0.2.1 baseline. No INTERNET permission, no cloud processing, no analytics or ad SDK, no accounts.

## What the offline workshop (`offline/index.html`) supports

| Input | Output | Important limitation |
|---|---|---|
| PNG/JPEG/WebP, and platform-supported BMP/GIF/AVIF/HEIC | PNG, JPEG, WebP | Animated GIF: first frame only; exotic decoder support depends on device |
| Browser-decodable images | BMP, TIFF, ICO | BMP/TIFF uncompressed; ICO single embedded PNG image, max 256×256 |
| Browser-decodable images | SVG | True vector contours or plotter centerlines; quality varies; **not** a manual/vector-AI reconstruction |
| PNG/JPG/WebP/BMP/GIF/AVIF/HEIC (when Android decoder supports it) | PDF | Image embedded on one A4 page, no OCR |
| TXT, MD, CSV, JSON | PDF, DOCX | Plain text export, not rich Markdown/Excel layout |
| DOCX | TXT, PDF | **Text only**; drops images, charts, styling and precise layout |
| PDF | PNG, JPG | **First page only** |
| PDF | ZIP containing PNG or JPG pages | Up to 20 pages, bounded by rendered pixel and output-size limits |
| MP4/MOV/M4V with AAC audio | M4A | AAC track remux only; does not transcode codecs |
| JSON, TXT, DOCX, PDF, pictures | Local preview | PDF first-page preview, DOCX extracted text, JSON pretty print |

The existing v0.2.1 browser-only image/CSV/JSON conversions, multi-file ZIP export, native Android file save, email sharing, and privacy controls are retained.

## Not yet implemented — do not advertise as working

- Legacy binary `.doc` and `.xls`, full-fidelity DOCX/PDF round-trip or PDF text extraction/OCR.
- Full Excel/PowerPoint conversion and formulas, general audio/video transcoding or large-video support.
- Professional/hand-refined Hawaii-quality vector art automatically for arbitrary images.
- On-device, end-to-end acceptance of **v0.3**: actual APK compilation and Android handset test are **pending**.

## Offline limits and security

- Android app has **zero Internet permissions**. Local `appassets.androidplatform.net` virtual host only; all input files use the system document picker.
- New offline document bridge accepts **≤6 MiB** input and ≤16 MiB output, limits PDF pixels, pages and Word XML size. Large files give errors, not hidden server calls.
- No third-party codecs or binary native libraries have been added; release avoids FFmpegKit, obsolete SDK downloads and risky permissions.
- PDF document creation and DOCX text extraction use Android framework/Java standard libraries. PDF pages use Android `PdfRenderer`, AAC audio remux uses `MediaExtractor` and `MediaMuxer`.
- Offline SVG is a local algorithm with two variants (outline and skeleton centerline); output contains real `<path>` elements, no embedded raster.

## Local checks

```bash
python3 scripts/audit_public_source.py
python3 scripts/verify_android.py
python3 scripts/test_offline_surface.py
node scripts/test_js_bridge.js
node scripts/test_offline_algorithms.js
```

For APK compilation use the GitHub Actions public build workflow after uploading the SHA-pinned ZIP. Test on actual Android 16 device before describing a feature as production-ready.
